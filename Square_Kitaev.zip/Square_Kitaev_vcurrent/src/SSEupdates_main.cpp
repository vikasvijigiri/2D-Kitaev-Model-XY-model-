#include "../include/SSEvariables.hpp"
#include "../include/SSElattice.hpp"
#include "../include/SSEobservables.hpp"
#include "../include/SSEupdates.hpp"
#include <iostream>
#include <list>
//#include <numeric> // for std::accumulate
//#if PARALLEL
//#include <execution>
//#define SEQ std::execution::seq,
//#define PAR std::execution::par,
//#else
//#define SEQ
//#define PAR
//#endif


static ran rann;
using namespace std;





void
SSEupdates::mcstep(SSElattice * lattice, SSEvariables & sv) {
  diag_update(lattice, sv);
  looper(lattice, sv);
}



void SSEupdates::diag_update(SSElattice *lattice, SSEvariables &sv)
{
    constexpr double epsilon = 1e-6;
    constexpr int k_max = 2;


    for (int i = 0; i < sv.Lc; ++i)
    {
        int& current_str = str[i];
        int& current_tbnd = tbnd[i];

        if (current_str < 0)
        {
            double cp = 0.0;
			      double r = rann();
            for (int k = 0; k < k_max; ++k)
            {
                cp += sv.cum_prob[k];
                if (cp > r && sv.cum_prob[k] > epsilon)
                {
                    int b = int(rann() * sv.Nb) + k * sv.Nb;
                    int ss1 = (1 + lattice[sv.JHsites[b][0]].S()) / 2;
                    int ss2 = (1 + lattice[sv.JHsites[b][1]].S()) / 2;
                    double p = ((1 - k) + k * awgt[ss1][ss2]) * sv.prob_in / float(sv.Lc - sv.n1);;
                    if (rann() < p)
                    {
                        current_str = b;
                        current_tbnd = legvx[ss1][ss2][ss1][ss2];
                        sv.n1 += 1;
                    }
                    break;
                }
            }
        }
        else
        {
            int& vx = current_tbnd;
            if (vxoper[vx] == 1 && rann() < sv.prob_rm * float(sv.Lc - sv.n1 + 1))
            {
                current_str = -1;
                vx = -1;
                sv.n1 -= 1;
            }
            else if (vxoper[vx] == 2)
            {
                int ss1 = sv.JHsites[current_str][0];
                int ss2 = sv.JHsites[current_str][1];
                lattice[ss1].set_S(2 * vxleg[2][vx] - 1);
                lattice[ss2].set_S(2 * vxleg[3][vx] - 1);
            }
//            else
//            {
//                std::cerr << "Error in vr type!" << std::endl;
//                exit(1);
//            }
        }
    }
}


void
SSEupdates::looper(SSElattice * lattice, SSEvariables& sv) {
  int o, v, vi, v0=0, v1, v2;
  int vx, ic, oc;
  double r, p;
  int s1, s2;//, ss1, ss2, tt1, tt2;
  int b;


  int * X = new int[4 * sv.n1]; // Linked-list
  bool * flag = new bool[4 * sv.n1];
  bool * galf = new bool[sv.Lc];
  int * lpos  = new int[sv.Lc]; // store positions of non-identity operator in the operator string of length Lc.

  //////////////////////////////////////////// Linked list construction	///////////////////////////////
  for (int i = 0; i < sv.Lc; ++i) {
    b = str[i];
    if (b >= 0) // there is a non-identity operator.
    {
      s1 = sv.JHsites[b][0];
      s2 = sv.JHsites[b][1];
      v1 = last[s1];
      v2 = last[s2];

      lpos[v0 / 4] = i;
      galf[i] = 0;
      //std::cout << "timsl:: " << i << "  " << "sitesss    " << s1 << " " << s2 << "  :: " << "  type: " << int(b / sv.Nb) << " which vertex: " << tbnd[i] << std::endl;
      if (v1 != -1) {
        X[v1] = v0;
        X[v0] = v1;
      } else {
        frst[s1] = v0;
      }

      if (v2 != -1) {
        X[v2] = v0 + 1;
        X[v0 + 1] = v2;
      } else {
        frst[s2] = v0 + 1;
      }

      last[s1] = v0 + 2;
      last[s2] = v0 + 3;
      flag[v0] = 0;
      flag[v0 + 1] = 0;
      flag[v0 + 2] = 0;
      flag[v0 + 3] = 0;
      v0 += 4;
    }
  }

  // PBC loops 
  for (int k = 0; k < sv.Ns; ++k) {
    v1 = frst[k];
    if (v1 != -1) {
      v2 = last[k];
      X[v2] = v1;
      X[v1] = v2;
    }
  }

  //for (int k = 0; k < v0; ++k)//std::cout << k << "------>" << X[k] << std::endl;

  //std::cout << std::endl;

//  auto customMultiply = [flag](bool accumulator, int element) {
//      return accumulator && flag[element] && flag[element+1] && flag[element+2] && flag[element+3];
//  };



 
  int i, l, vxi;
  if (v0 != 0) {
    for (int j = 0; j < sv.nl; j++) {
      v1 = int(rann() * v0);

      // xx caretaker
      ic = v1 % 4;
      i = lpos[v1 / 4];
      b = str[i];
      if (int(b/sv.Nb) < 1) {
        //std::cout << " vi " << " = " << v1  << std::endl;
        vi = v1;
        while (1) {
          ic = v1 % 4;
          i = lpos[v1 / 4];
          b = str[i];
          v = 4 * (int(v1 / 4));            
          if (int(b/sv.Nb) < 1) {
            vx = tbnd[i];
            p = 0;
            r = rann();
            for (oc = 0; oc < 4; ++oc) {
              p += vxprb[oc][ic][vx];
              if (r < p) {
                tbnd[i] = vxnew[oc][ic][vx];
                break;
              }
            }
          } else {
            oc = ic;
          }
          v2 = v + oc;
          v1 = X[v2];
          if (v1 == vi or v2 == vi) break;
        }
      } else {

        // zz caretaker
        vxi = tbnd[i];
        cstack.push_back(v1);
        while (!cstack.empty()) 
        {
          v1 = cstack.front();
          cstack.pop_front();
          i = lpos[v1 / 4];
          b = str[i];
          //std::cout << " vi " << " = " << v1  << std::endl;
          vi = v1;
          if (flag[v1] == 0){
            while (1) {
              ic = v1 % 4;
              i = lpos[v1 / 4];
              b = str[i];
              v = 4 * (int(v1 / 4));
              vx = tbnd[i];
              l = v1 + pow(-1, v1);
              if (galf[i] == 1)vx = vx + pow(-1,vx+1);              
              if (vx == vxi || int(b/sv.Nb) < 1){ 
                oc = 3 - ic;      //ic + 2*pow(-1,1+(1-int(ic/2))); //ic int(rann()* 4);
                v2 = v + oc;                
                if (galf[i] == 0) {cstack.push_back(l); tbnd[i] = vx + pow(-1,vx+1);}
                flag[v1] = galf[i] = flag[v2] = 1;  //!flag[v1];
                //flag[v2] = 1;//!flag[v2];
                //galf[i] = 1;
                //std::cout << "T: " << i << "  " << " V1--v2--X[v2] =       " << v1 << " -  " << v2 << "  --  " << X[v2] << "  type: " << int(b / sv.Nb) << " which vertex: " << tbnd[i] <<std::endl;          
                v1 = X[v2];
                if (v1 == vi || v2 == vi) break;
              } else {
                break;
              }
          }
        }
          //std::cout << std::endl;
        }
        cstack.clear();
      }
    }
  }




  /////////////////////////////////////// Update spin configuration here	//////////////////////
  for (int j = 0; j < sv.Ns; ++j) {
    if (last[j] != -1) {
      i = lpos[int(last[j] / 4)];
      o = tbnd[i];
      b = last[j] % 4;

      //ss1 = lattice[j].S();
      lattice[j].set_S(2 * vxleg[b][o] - 1);
      //ss2 = lattice[j].S();
      //std::cout << ss1 << " -->  " << ss2 << "  site:  " << j << std::endl;

    } else {
      if (rann() < 0.5) lattice[j].flip(); // flip isolated spins with prob half.
    }

    last[j] = -1;
    frst[j] = -1;
  }
  delete[] X;
  delete[] flag;
  delete[] galf;
  delete[] lpos;
}
