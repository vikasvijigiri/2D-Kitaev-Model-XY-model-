#include "../include/SSEvariables.hpp"
#include "../include/SSElattice.hpp"
#include "../include/SSEobservables.hpp"
#include "../include/SSEupdates.hpp"
#include <iostream>
#include <deque>

static ran rann;
using namespace std;

void
SSEupdates::mcstep(SSElattice *lattice, SSEvariables &sv)
{
	diag_update(lattice, sv);
	looper(lattice, sv);
}




void
SSEupdates::diag_update(SSElattice *lattice, SSEvariables &sv)
{
	int b, o, ss1, ss2, vx;
	double p, r, cp;

	/*
	int dumm_latt[9];

	for (long i = 0; i < sv.Ns; ++i) {
		dumm_latt[i] = lattice[i].S();
		//////std::cout << lattice[i].S();
	} 
	*/

	for (long i = 0; i < sv.Lc; ++i)
	{
		o = str[i];
		if (o < 0)
		{
			// Identity operator
			r = rann();
			cp = 0.0;
			for (int k = 0; k < 2; k++)
			{
				// k = 0 >> Jx-bond, k = 1 >> Jz-bond.
				cp += sv.cum_prob[k];
				if (cp > r and sv.cum_prob[k] > 1e-6)
				{
					b = int(rann() *sv.Nb) + k *sv.Nb;	// b = 0 to Nb are Jx-bonds, b = Nb to 2Nb are Jz-bonds.				
					ss1 = (1 + lattice[sv.JHsites[b][0]].S()) / 2;
					ss2 = (1 + lattice[sv.JHsites[b][1]].S()) / 2;
					p = (1 - k) + k *awgt[ss1][ss2];	// for inserting a Jz- diagonal operator, both spins should be same. 

					p = p *sv.prob_in / float(sv.Lc - sv.n1);	// prob. of inserting a diagonal operator
					if (rann() < p)
					{
						str[i] = b;
						tbnd[i] = legvx[ss1][ss2][ss1][ss2];
						sv.n1 += 1;
					    break;
					}
				}
			}
		}
		else
		{
			vx = tbnd[i];
			if (vxoper[vx] == 1)	// its a diagonal operator.
			{
				p = sv.prob_rm* float(sv.Lc - sv.n1 + 1);	// prob. of removing a diagonal operator
				if (rann() < p)
				{
					str[i] = -1;
					tbnd[i] = -1;
					sv.n1 -= 1;
				}
			}
			else if (vxoper[vx] == 2)
			{
				// its a off-diagonal operator (Jx-operator)
				ss1 = sv.JHsites[o][0];
				ss2 = sv.JHsites[o][1];
				lattice[ss1].set_S(2 *vxleg[2][vx] - 1);
				lattice[ss2].set_S(2 *vxleg[3][vx] - 1);
			}
			else
			{
			 	////std::cout << ("Error in vr type!") << std::endl;
				exit(1);
			}
		}
	}

    /*
    int i ;

    i = 0;
    b = 9;
    str[i] = b;
    lattice[sv.JHsites[b][0]].set_S(1);
    lattice[sv.JHsites[b][1]].set_S(1);
	ss1 = (1 + lattice[sv.JHsites[b][0]].S()) / 2;
	ss2 = (1 + lattice[sv.JHsites[b][1]].S()) / 2;
    tbnd[i] = legvx[ss1][ss2][ss1][ss2];

    i = 5;
    b = 10;
    str[i] = b ;
    lattice[sv.JHsites[b][0]].set_S(1);
    lattice[sv.JHsites[b][1]].set_S(1);
	ss1 = (1 + lattice[sv.JHsites[b][0]].S()) / 2;
	ss2 = (1 + lattice[sv.JHsites[b][1]].S()) / 2;
    tbnd[i] = legvx[ss1][ss2][ss1][ss2];


    i = 8;
    b = 0;
    str[i] = b ;
	ss1 = (1 + lattice[sv.JHsites[b][0]].S()) / 2;
	ss2 = (1 + lattice[sv.JHsites[b][1]].S()) / 2;
    tbnd[i] = legvx[ss1][ss2][ss1][ss2];
    
    sv.n1 = 3;
    */
}


void
SSEupdates::looper(SSElattice *lattice, SSEvariables &sv)
{
	long o, v, vi, v0, v1, v2;
	int vx, ic, oc;
	int s1, s2, ss1, ss2, tt1, tt2;
	int b;
	double r, p;

	long *X = new long[4 *sv.n1];	// Linked-list

	int *lpos = new int[sv.Lc];	// store positions of non-identity operator in the operator string of length Lc.
	
	//////////////////////////////////////////// Linked list construction	///////////////////////////////
	v0 = 0;
	for (long i = 0; i < sv.Lc; ++i)
	{
		o = str[i];
		if (o >= 0)    // there is a non-identity operator.
		{
			b = o;
			s1 = sv.JHsites[b][0];
			s2 = sv.JHsites[b][1];
			v1 = last[s1];
			v2 = last[s2];

			lpos[int(v0 / 4)] = i;

			if (v1 != -1)
			{
				X[v1] = v0;
				X[v0] = v1;
			}
			else
			{
				frst[s1] = v0;
			}

			if (v2 != -1)
			{
				X[v2] = v0 + 1;
				X[v0 + 1] = v2;
			}
			else
			{
				frst[s2] = v0 + 1;
			}

			last[s1] = v0 + 2;
			last[s2] = v0 + 3;

			v0 += 4;
			
		}
	}

	// PBC loops 
	for (int k = 0; k < sv.Ns; ++k)
	{
		v1 = frst[k];
		if (v1 != -1)
		{
			v2 = last[k];
			X[v2] = v1;
			X[v1] = v2;
		}
	}
	/////////////////////////// Main diagonal-offdiagonal update >> loop update	/////////////////////////////////

  nl = 10*sv.lx;
  long i;
	int l;
	
  for (int j = 0; j < nl; j++) {
    vi = long(rann() * v0);
    v1 = vi;
    i = lpos[v1/4];   // time-slice number
		if (v0!=0){   // v0 != 0  if there is atleast one non-identity operator in the operator string.
		  while (1) {
		    ic = v1 % 4;
		    b = str[i];
		    if (b >= 0 and b < sv.Nb){    // its a Jx -vertex
		      r = rann();
		      vx = tbnd[i];
		      p = 0;
		      for (oc = 0; oc < 4; ++oc) {
		        p += vxprb[oc][ic][vx];
		        if (r < p) {
		          l = vxnew[oc][ic][vx];
							tbnd[i] = l;
		          break;
		        }
		      }
		    }
				else{       // its a Jz - vertex
					oc = ic; // bounce with prob 1.
				}

		    v2 = 4 * (long(v1 / 4)) + oc;
		    v = X[v2];
		    if (v == vi or v2 == vi) {
		      break;
		    } else {
		      v1 = v;
		      i = lpos[v1/4];
		    }
		  }
		}
  }

	/////////////////////////////////////// Update spin configuration here	//////////////////////
	for (int j = 0; j < sv.Ns; ++j)
	{
		if (last[j] != -1)
		{
			i = lpos[int(last[j] / 4)];
			o = tbnd[i];
			b = last[j] % 4;
			
			lattice[j].set_S(2 *vxleg[b][o] - 1);
		}

		else{                          // flip isolated spins with prob half.
			ss1 = lattice[j].S ();
			if (rann() < 0.5){
				lattice[j].flip();
			}
			ss1 = lattice[j].S ();
		}

		last[j] = -1;
		frst[j] = -1;
	}

	delete[] X;
	delete[] lpos;
}













