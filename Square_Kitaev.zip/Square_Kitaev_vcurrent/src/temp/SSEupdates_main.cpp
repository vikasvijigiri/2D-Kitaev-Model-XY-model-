#include "../include/SSEvariables.hpp"
#include "../include/SSElattice.hpp"
#include "../include/SSEobservables.hpp"
#include "../include/SSEupdates.hpp"
#include <iostream>
#include <deque>

static ran rann;
using namespace std;

void
SSEupdates::mcstep(SSElattice *lattice, SSEvariables &sv)
{
	diag_update(lattice, sv);
	looper(lattice, sv);
}



void
SSEupdates::diag_update(SSElattice *lattice, SSEvariables &sv)
{
	int b, o, ss1, ss2, vx;
	double p, r, cp;

	/*
	int dumm_latt[9];

	for (long i = 0; i < sv.Ns; ++i) {
		dumm_latt[i] = lattice[i].S();
		////std::cout << lattice[i].S();
	} 
	*/

	for (long i = 0; i < sv.Lc; ++i)
	{
		o = str[i];
		if (o < 0)
		{
			// Identity operator
			r = rann();
			cp = 0.0;
			for (int k = 0; k < 2; k++)
			{
				// k = 0 >> Jx-bond, k = 1 >> Jz-bond.
				cp += sv.cum_prob[k];
				if (cp > r and sv.cum_prob[k] > 1e-6)
				{
					b = int(rann() *sv.Nb) + k *sv.Nb;	// b = 0 to Nb are Jx-bonds, b = Nb to 2Nb are Jz-bonds.				
					ss1 = (1 + lattice[sv.JHsites[b][0]].S()) / 2;
					ss2 = (1 + lattice[sv.JHsites[b][1]].S()) / 2;
					p = (1 - k) + k *awgt[ss1][ss2];	// for inserting a Jz- diagonal operator, both spins should be same. 

					p = p *sv.prob_in / float(sv.Lc - sv.n1);	// prob. of inserting a diagonal operator
					if (rann() < 0)//p)
					{
						str[i] = b;
						tbnd[i] = legvx[ss1][ss2][ss1][ss2];
						sv.n1 += 1;
					    break;
					}
				}
			}
		}
		else
		{
			vx = tbnd[i];
			if (vxoper[vx] == 1)	// its a diagonal operator.
			{
				p = sv.prob_rm* float(sv.Lc - sv.n1 + 1);	// prob. of removing a diagonal operator
				if (rann() < p)
				{
					str[i] = -1;
					tbnd[i] = -1;
					sv.n1 -= 1;
				}
			}
			else if (vxoper[vx] == 2)
			{
				// its a off-diagonal operator (Jx-operator)
				ss1 = sv.JHsites[o][0];
				ss2 = sv.JHsites[o][1];
				lattice[ss1].set_S(2 *vxleg[2][vx] - 1);
				lattice[ss2].set_S(2 *vxleg[3][vx] - 1);
			}
			else
			{
			 	//std::cout << ("Error in vr type!") << std::endl;
				exit(1);
			}
		}
	}

    int i ;

    i = 0;
    b = 9;
    str[i] = b;
    lattice[sv.JHsites[b][0]].set_S(1);
    lattice[sv.JHsites[b][1]].set_S(1);
	ss1 = (1 + lattice[sv.JHsites[b][0]].S()) / 2;
	ss2 = (1 + lattice[sv.JHsites[b][1]].S()) / 2;
    tbnd[i] = legvx[ss1][ss2][ss1][ss2];

    i = 5;
    b = 10;
    str[i] = b ;
    lattice[sv.JHsites[b][0]].set_S(1);
    lattice[sv.JHsites[b][1]].set_S(1);
	ss1 = (1 + lattice[sv.JHsites[b][0]].S()) / 2;
	ss2 = (1 + lattice[sv.JHsites[b][1]].S()) / 2;
    tbnd[i] = legvx[ss1][ss2][ss1][ss2];


    i = 8;
    b = 0;
    str[i] = b ;
	ss1 = (1 + lattice[sv.JHsites[b][0]].S()) / 2;
	ss2 = (1 + lattice[sv.JHsites[b][1]].S()) / 2;
    tbnd[i] = legvx[ss1][ss2][ss1][ss2];
    
    sv.n1 = 3;
}



void
SSEupdates::looper(SSElattice *lattice, SSEvariables &sv)
{
	long o, v, vi, v0, v1, v2;
	int vx, ic, oc;
	int s1, s2, ss1, ss2, tt1, tt2;
	int b;
	double r, r1, p;

	long *X = new long[4 *sv.n1];	// Linked-list
	bool *flag = new bool[4* sv.n1];
	bool *galf = new bool[sv.Lc];
	int *lpos = new int[sv.Lc];	// store positions of non-identity operator in the operator string of length Lc.

	//////////////////////////////////////////// Linked list construction	///////////////////////////////
	v0 = 0;
	for (long i = 0; i < sv.Lc; ++i)
	{
		o = str[i];
		if (o >= 0)	// there is a non-identity operator.
		{
			b = o;
			s1 = sv.JHsites[b][0];
			s2 = sv.JHsites[b][1];
			v1 = last[s1];
			v2 = last[s2];

			lpos[int(v0 / 4)] = i;
            galf[i] = false;
			std::cout << "timsl:: " << i << "  "  << "sitesss    "  << s1   << " " << s2  << "  :: " << "  type: " << int(b / sv.Nb) << " which vertex: " << tbnd[i] << std::endl;
			if (v1 != -1)
			{
				X[v1] = v0;
				X[v0] = v1;
			}
			else
			{
				frst[s1] = v0;
			}

			if (v2 != -1)
			{
				X[v2] = v0 + 1;
				X[v0 + 1] = v2;
			}
			else
			{
				frst[s2] = v0 + 1;
			}

			last[s1] = v0 + 2;
			last[s2] = v0 + 3;
			flag[v0]   = false;
			flag[v0+1] = false;
			flag[v0+2] = false;
			flag[v0+3] = false;
			v0 += 4;
		}
	}

	// PBC loops 
	for (int k = 0; k < sv.Ns; ++k)
	{
		v1 = frst[k];
		if (v1 != -1)
		{
			v2 = last[k];
			X[v2] = v1;
			X[v1] = v2;
		}
	}

	//for (int k = 0; k < v0; ++k)std::cout << k << "------>" << X[k] << std::endl;


    std::cout << std::endl;
	/////////////////////////// Main diagonal-offdiagonal update >> loop update	/////////////////////////////////
	nl = 1;//10 * sv.lx;
	long i;
	int l, count=0;

	deque<int> zstack, xstack, cstack;
	for (int j = 0; j < nl; j++)
	{
		vi = 10;//long(rann() *v0);
		v1 = vi;
		i = lpos[v1 / 4];	// time-slice number

        // START FROM RANDOM LEG
		cstack.push_front(v1);

		//if (X[v1] < 1) continue;
		//std::cout << i << std::endl;
		//std::cout << i << " initial " << flag[i] << "  " << vi << std::endl;
        //std::cout << "start time = " << i << " , start vx " << " = " << v1  << std::endl << std::endl;
		r = rann();
		if (v0 != 0 and !flag[v1]){
		    //{
		    // v0 != 0  if there is atleast one non-identity operator in the operator string.
		    while (!cstack.empty())//for (l = 0; l < 10; ++l)//
		    {
			    v1 = cstack.back();
			    cstack.pop_back();
			    i = lpos[v1 / 4];
			    b = str[i];
                std::cout << " vi " << " = " << v1 << " Prob = " << r << std::endl;
			    //if (b >= 0 and b < sv.Nb) // IF XX BOND 
			    //{
				    //xstack.push_front(v1);
                    vi = v1;
                    //std::cout << "xstack size " << xstack.size() << std::endl;
				    //std::cout << " Vx: " << v1 << "  " << i << " -> " << tbnd[i] << std::endl;
                    //std::cout << std::endl;
                    count = 0;
				    while (1)
				    {
					    //v1 = xstack.back();
					    //xstack.pop_back();
					    ic = v1 % 4;
					    i = lpos[v1 / 4];
					    b = str[i];
					    //std::cout << " Vx: " << v1  << "  " << i << " -> " << tbnd[i] << std::endl;
					    if (b >= 0 and b < sv.Nb)
					    {

						    vx = tbnd[i];
						    p = 0;
                            r1 = rann();
						    //oc = ic + pow(-1, ic);
						    for (oc = 0; oc < 4; ++oc)
						    {
							    p += vxprb[oc][ic][vx];
						        if (r1 < p)
						        {
							        if (r > 0.5)tbnd[i]  = vxnew[oc][ic][vx];
							        break;
						        }
						    }
						    v2 = 4 *(long(v1 / 4)) + oc;
					        flag[v1] = !flag[v1]; // VERTEX VISITED
					        flag[v2] = !flag[v2];  
                            galf[i]  = true;
                            v = v1;
						    v1 = X[v2];
                            //if (flag[v1] == 0) cstack.push_front(v1);
                            std::cout << " V1 = " << v  << " v2 =  " << v2 << "  : Link to  " << v1 << std::endl;
                            if (v1 == vi or v2 == vi) break;
                           //if (v1 == vi or v2 == vi) break;
						   //std::cout << " Vx: " << v1 << " --> " << v2 << " --> " << v << "          || vx type: " << v << " -> " << tbnd[i] << std::endl;
						   //flag[i] = -1;	//flag[v2] = -1;
					    } else
					    {
                            oc = ic + 2*pow(-1,1+(1-int(ic/2))); //ic int(rann()* 4);
					        v2 = 4 *(long(v1 / 4)) + oc;
                            v = v1;
                            i = lpos[v1 / 4];
                            if(!galf[i]){cstack.push_front(v1+pow(-1,v1));cstack.push_front(v2+pow(-1,v2));}
                            vx = tbnd[i];       
                            if (r > 0.5)tbnd[i] = vx + pow(-1, vx + 1);
                            flag[v1] = !flag[v1];
                            flag[v2] = !flag[v2];
					        v1 = X[v2];
                            //v = 4 *(long(v1 / 4))
                            galf[i] = true; 
                            std::cout << " V1 = " << v  << " v2 =  " << v2 << "  : Link to  " << v1 << std::endl;
                            if (v1 == vi or v2 == vi) break;
                            //std::cout << "Here " << std::endl;
						    //flag[v1] = -1;
						    //i = lpos[v1 / 4];
                                
						    //break;
					    }
                        count += 1;
				    }
                    std::cout << std::endl;
			    //}
/*
			    else
			    {
			     	//std::cout << "here  " << std::endl;
                    if(!flag[v1])zstack.push_front(v1);
				    v = 4 *(long(v1 / 4));
				    zstack.push_front(v);
				    zstack.push_front(v + 1);
				    zstack.push_front(v + 2);
				    zstack.push_front(v + 3);

				    i  = lpos[v1 / 4];
				    vx = tbnd[i];
				    if (r > 0.5 and flag[v])tbnd[i] = vx + pow(-1, vx + 1);

				    std::cout  << "tikkum: " << i << "     " << vx << "   " << tbnd[i] << std::endl;

				    galf[i] = -1;
				    //in_cluster[i] = ccount



				    //vx = tbnd[i];			
				    while (!zstack.empty())
				    {
					    v1 = zstack.back();
                        v = v1;
                        //std::cout << " Vx: " << v1  << " -->  " << v2 << "  : Link to  " << v << std::endl;
					    i = lpos[v1 / 4];
					    //std::cout << X[v1] << " " << v1 << "  rann   " << r << std::endl;
					    b = str[i];
					    vx = tbnd[i];
					    zstack.pop_back();

					    if (!galf[i] and !flag[v1])
					    {
						    if (b >= 0 and b < sv.Nb)
						    {
						     	//std::cout << X[v1] << " IN " << v1 << "    " << i << std::endl;
                                std::cout << " c in z time: " << i  << " -->  " << v << "  : Link to  " << v1 << std::endl;
							    cstack.push_front(v1);
                                //galf[i] = -1;
                                //break;
							    //flag[v1] = -1;
						    }
						    else
						    {
                                std::cout << " time: " << i  << " -->  " << v << "  : Link to  " << v1 << std::endl;
						     	//std::cout << X[v1] << " IN " << v1 << "    " << i << std::endl;
							    v = 4 *(long(v1 / 4));
							    zstack.push_front(v);
							    zstack.push_front(v + 1);
							    zstack.push_front(v + 2);
							    zstack.push_front(v + 3);

							    galf[i] = true;
							    //std::cout << "Inside: " << i <<  "   " << v1 << std::endl;
							    if (r > 0.5)tbnd[i] = vx + pow(-1, vx + 1);
						    }
					    }
					    v1 = X[v1];
				    }
			    }
*/
		    }
	    }
	    xstack.clear();
	    zstack.clear();
	    cstack.clear();
    }


    /*

      nl = 10*sv.lx;
      long i;
      int l;
	    
      for (int j = 0; j < nl; j++) {
        vi = long(rann() * v0);
        v1 = vi;
          // time-slice number
		    if (v0!=0){   // v0 != 0  if there is atleast one non-identity operator in the operator string.
		      while (1) {
		        ic = v1 % 4;
                i = lpos[v1/4]; 
		        b = str[i];
		        if (b >= 0 and b < sv.Nb){    // its a Jx -vertex
		          r = rann();
		          vx = tbnd[i];
		          p = 0;
		          for (oc = 0; oc < 4; ++oc) {
		            p += vxprb[oc][ic][vx];
		            if (r < p) {
		              tbnd[i] = vxnew[oc][ic][vx];
		              break;
		            }
		          }
		        } else{       // its a Jz - vertex
				    oc = ic; // bounce with prob 1.
			    }
		        v2 = 4 * (long(v1 / 4)) + oc;
		        v1 = X[v2];
		        if (v1 == vi or v2 == vi) break;
		      }
		    }
      }
    */
	/////////////////////////////////////// Update spin configuration here	//////////////////////
	for (int j = 0; j < sv.Ns; ++j)
	{
		if (last[j] != -1)
		{
			i = lpos[int(last[j] / 4)];
			o = tbnd[i];
			b = last[j] % 4;

            ss1 = lattice[j].S();
			lattice[j].set_S(2 *vxleg[b][o] - 1);
            ss2 = lattice[j].S();

            std::cout << ss1 << " -->  "  << ss2 << "  site:  " << j << std::endl; 
            
            		
        }
		else
		{
			// flip isolated spins with prob half.
			//ss1 = lattice[j].S();
			if (rann() < 0.5)
			{
				lattice[j].flip();
			}

			//ss1 = lattice[j].S();
		}

		last[j] = -1;
		frst[j] = -1;
	}
    //std::cout << std::endl;
	delete[] X;
    delete[] flag;
    delete[] galf;
	delete[] lpos;
}
