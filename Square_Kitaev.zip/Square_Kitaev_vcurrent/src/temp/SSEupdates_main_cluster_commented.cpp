#include "../include/SSEvariables.hpp"
#include "../include/SSElattice.hpp"
#include "../include/SSEupdates.hpp"
	//#include "../include/SSEobservables.hpp"
#include <iostream>
#include <deque>

static ran rann;
using namespace std;

void
SSEupdates::mcstep(SSElattice *lattice, SSEvariables &sv)
{
	diag_update(lattice, sv);
	looper(lattice, sv);
}

void
SSEupdates::mcstep_measurement(SSElattice *lattice, SSEvariables &sv)
{
	diag_update_measurement(lattice, sv);
	looper(lattice, sv);
}


void
SSEupdates::diag_update(SSElattice *lattice, SSEvariables &sv)
{
	int b, o, t, ss1, ss2;
	double p, r, cp;


	for (long i = 0; i < sv.Lc; ++i)
	{
		o = str[i];
		//t = tbnd[i];
		if (o < 0){
      r = rann();
      cp = 0.0;
      for (int k = 0; k < 2; k++) {
        	cp += sv.cum_prob[k];
					if (cp > r and sv.cum_prob[k] > 1e-6){
						b = int(rann() *sv.Nb) + k*sv.Nb;									// bond number from 0 to Nb are Jx-bonds.					
						ss1 = (1 + lattice[sv.JHsites[b][0]].S()) / 2;
						ss2 = (1 + lattice[sv.JHsites[b][1]].S()) / 2;
						p = (1-k)+k*awgt[ss1][ss2];															// * sv.prob_in[1] / float(sv.Lc - sv.n1);	// prob. of inserting a diagonal operator
						// it's an Identity operator

						p = p *sv.prob_in / float(sv.Lc - sv.n1);	// prob. of inserting a diagonal operator
						if (rann() < p)	// Bond
						{
							str[i] = b;
							sv.n1 += 1;
						}
          break;
					}
			}
		}
		else //if (o >= 0 and o < sv.Nb)
		{
			if (vxoper[tbnd[i]] == 1)
			{
				// operator is of diagonal type. No restriction on spin configuration.
				p = sv.prob_rm *float(sv.Lc - sv.n1 + 1);	// prob. of deleting a diagonal operator
				if (rann() < p)
				{
					str[i] = -1;
					sv.n1 -= 1;
				}
			}
		}
	}


	std::cout << "Vikas " << std::endl;
	/*
	// (7, 8)
	b = 1;
	str[2] = b;
	sv.n1 = 1;





	// (7, 8)
	b = 0;
	str[5] = b;
	sv.n1 += 1;
	*/

	//lattice[sv.JHsites[b][0]].set_S(-1);
	//lattice[sv.JHsites[b][1]].set_S(-1);
	/*
	// (7, 1)
	b = 16;
	str[4] = b;
	sv.n1 += 1;
	lattice[sv.JHsites[b][0]].set_S(-1);
	lattice[sv.JHsites[b][1]].set_S(-1);

	// (2, 5)
	b = 11;
	str[5] = b;
	sv.n1 += 1;
	lattice[sv.JHsites[b][0]].set_S(-1);
	lattice[sv.JHsites[b][1]].set_S(-1);

	// (5, 3)
	b = 5;
	str[8] = b;
	sv.n1 += 1;
	lattice[sv.JHsites[b][0]].set_S(-1);
	lattice[sv.JHsites[b][1]].set_S(-1);

	// (1, 4)
	b = 10;
	str[10] = b;
	sv.n1 += 1;
	lattice[sv.JHsites[b][0]].set_S(-1);
	lattice[sv.JHsites[b][1]].set_S(-1);

	// (7, 1)
	b = 16;
	str[11] = b;
	sv.n1 += 1;
	lattice[sv.JHsites[b][0]].set_S(-1);
	lattice[sv.JHsites[b][1]].set_S(-1);

	// (1, 2)
	b = 1;
	str[12] = b;
	sv.n1 += 1;
	lattice[sv.JHsites[b][0]].set_S(-1);
	lattice[sv.JHsites[b][1]].set_S(-1);

	// (7, 8)
	b = 7;
	str[14] = b;
	sv.n1 += 1;
	lattice[sv.JHsites[b][0]].set_S(-1);
	lattice[sv.JHsites[b][1]].set_S(1);

	// (6, 7)
	b = 6;
	str[16] = b;
	sv.n1 += 1;
	lattice[sv.JHsites[b][0]].set_S(1);
	lattice[sv.JHsites[b][1]].set_S(-1);

	// (7, 8)
	b = 7;
	str[18] = b;
	sv.n1 += 1;
	lattice[sv.JHsites[b][0]].set_S(-1);
	lattice[sv.JHsites[b][1]].set_S(1);
	*/




}


void
SSEupdates::diag_update_measurement(SSElattice * lattice, SSEvariables& sv) {
	int b, o, t, ss1, ss2;
	double p, r, cp;

	for (long i = 0; i < sv.Lc; ++i)
	{
		o = str[i];
		if (o < 0){
      r = rann();
      cp = 0.0;
      for (int k = 0; k < 2; k++) {
        	cp += sv.cum_prob[k];
					if (cp > r and sv.cum_prob[k] > 1e-6){
						b = int(rann() *sv.Nb) + k*sv.Nb;									// bond number from 0 to Nb are Jx-bonds.					
						ss1 = (1 + lattice[sv.JHsites[b][0]].S()) / 2;
						ss2 = (1 + lattice[sv.JHsites[b][1]].S()) / 2;
						p = (1-k)+k*awgt[ss1][ss2];															// * sv.prob_in[1] / float(sv.Lc - sv.n1);	// prob. of inserting a diagonal operator
						// it's an Identity operator

						p = p *sv.prob_in / float(sv.Lc - sv.n1);	// prob. of inserting a diagonal operator
						if (rann() < p)	// Bond
						{
							str[i] = b;
							sv.n1 += 1;
						}
          break;
					}
			}
		}
		else //if (o >= 0 and o < sv.Nb)
		{
			if (vxoper[tbnd[i]] == 1)
			{
				// operator is of diagonal type. No restriction on spin configuration.
				p = sv.prob_rm *float(sv.Lc - sv.n1 + 1);	// prob. of deleting a diagonal operator
				if (rann() < p)
				{
					str[i] = -1;
					sv.n1 -= 1;
				}
			}
		}
	}




	enrg += float(sv.n1);
}

void
SSEupdates::looper(SSElattice *lattice, SSEvariables &sv)
{
	long o, v, vi, v0, v1, v2, t;
	int vx, ic, oc;
	int s1, s2, ss1, ss2, tt1, tt2;
	int b;
	double r, p;

	long *X = new long[4 *sv.n1];	// Linked-list
	long *flag = new long[4* sv.n1];
	long *galf = new long[sv.Lc];
	//tbnd = int[sv.Lc];
	int *lpos = new int[sv.Lc];	// store positions of non-identity operator in the operator string of length Lc.
	//std::cout<<"removal 0"<<std::endl;
	//////////////////////////////////////////// Linked list construction	///////////////////////////////
	v0 = 0;
	for (long i = 0; i < sv.Lc; ++i)
	{
		o = str[i];
		if (o >= 0)
		{
			// there is a non-identity operator.
			b = o;
			s1 = sv.JHsites[b][0];
			s2 = sv.JHsites[b][1];


			//std::cout<< "sitesss    " << s1 << " " << s2 << std::endl;
			v1 = last[s1];
			v2 = last[s2];

			ss1 = (1 + lattice[s1].S()) / 2;
			ss2 = (1 + lattice[s2].S()) / 2;



			if (o < sv.Nb)
			{
				if (vxoper[tbnd[i]] == 2)
				{
					tt1 = 1 - ss1;
					tt2 = 1 - ss2;
				}
				else if (vxoper[tbnd[i]] == 1)
				{
					tt1 = ss1;
					tt2 = ss2;
				}
				else
				{
					std::cout << "errrr     " << std::endl;
					exit(1);
				}
			}
			else
			{
				tt1 = ss1;
				tt2 = ss2;
			}

			tbnd[i] = legvx[ss1][ss2][tt1][tt2];	// tbnd[i] stores the vertextype at time-slice i.
			std::cout<< "sitesss    " << s1 << " " << s2 << " :: " << ss1 << "  " << ss2   << "  type: "<< int(b/sv.Nb) << "  " << tbnd[i] << std::endl;
			lpos[int(v0 / 4)] = i;
			galf[i] = 0;

			if (v1 != -1)
			{
				X[v1] = v0;
				X[v0] = v1;
			}
			else
			{
				frst[s1] = v0;
			}

			if (v2 != -1)
			{
				X[v2] = v0 + 1;
				X[v0 + 1] = v2;
			}
			else
			{
				frst[s2] = v0 + 1;
			}

			last[s1] = v0 + 2;
			last[s2] = v0 + 3;
			flag[v0] = 0;
			flag[v0+1] = 0;
			flag[v0+2] = 0;
			flag[v0+3] = 0;
		

			v0 += 4;
			
		}
	}

	// PBC loops 
	for (int k = 0; k < sv.Ns; ++k)
	{
		v1 = frst[k];
		if (v1 != -1)
		{
			v2 = last[k];
			X[v2] = v1;
			X[v1] = v2;
		}
	}

	
	  for (int k = 0; k < v0; ++k) 
		{ 	
			std::cout << k << "   " << X[k] << "   " << sv.n1<< std::endl;
		} 
	
	 
	//////////////////////////////////////////////////////////////////////////////////////////////////////////
	//std::cout<<"removal 1"<<std::endl;
	/////////////////////////// Main diagonal-offdiagonal update >> loop update	/////////////////////////////////


	/*
	nl = 5;//5 *sv.lx;
	long i;
	int l;

	

	deque<int> zstack, xstack, cstack;

	for (int j = 0; j < nl; j++)
	{
		vi = long(rann() *v0);
		v1 = vi;
		i = lpos[v1 / 4];	// time-slice number
		cstack.push_front(v1);
		//if (X[v1] < 1) continue;
		//std::cout << i << std::endl;
		std::cout << i << " initial " << flag[i] << "  " << vi << std::endl;		
		r = rann();
		//if (v0 != 0 and flag[i] == 0)
		//{
			// v0 != 0  if there is atleast one non-identity operator in the operator string.
			while (!cstack.empty())
			{
				v1 = cstack.back();
				cstack.pop_back();
				i = lpos[v1 / 4];
				b = str[i];
				if (b >= 0 and b < sv.Nb){
				xstack.push_front(v1);
					std::cout << " Vx: " << v1  << "  " << i << " -> " << tbnd[i] << std::endl;
				while (!xstack.empty())
				{
						v1 = xstack.back();
						xstack.pop_back();
						ic = v1 % 4;
						i = lpos[v1/4];
						b = str[i];
						//std::cout << " Vx: " << v1  << "  " << i << " -> " << tbnd[i] << std::endl;
						if (b >= 0 and b < sv.Nb)
						{
							r = rann();
							vx = tbnd[i];
							p = 0;
							//oc = ic + pow(-1, ic);
							flag[v1] = -1;
							for (oc = 0; oc < 4; ++oc)
							{	
									v2 = 4 *(long(v1 / 4)) + oc;
									p += vxprb[oc][ic][vx];
									if (galf[i] < 0){
										if (flag[v2] == 0 and ic != oc){
											tbnd[i] = vxnew[oc][ic][vx];
											flag[v2] = -1;
											break;
										}
									} else {
										if (r < p)
										{
											tbnd[i] = vxnew[oc][ic][vx];
											galf[i] = -1;
											flag[v2] = -1;
											break;
										}
									}
							}
							
							
							v = X[v2];
							if(flag[v]==0)xstack.push_front(v);
							std::cout << " Vx: " << v1 << " --> " << v2  << " --> " << v << "          || vx type: " << v << " -> " << tbnd[i] << std::endl; 
							//flag[i] = -1; //flag[v2] = -1;
  							

						}
						else 
						{
							if (flag[i]==0){
								cstack.push_front(v1);
								//flag[v1] = -1;
								i = lpos[v1 / 4];
							}							
							//break;
						}
					}
				}
				else
				{
					//std::cout << "here  " << std::endl;

					v = 4 *(long(v1 / 4));
					zstack.push_front(v);
					zstack.push_front(v + 1);
					zstack.push_front(v + 2);
					zstack.push_front(v + 3);
					
					
					i = lpos[v1 / 4];
					vx = tbnd[i];
					
					tbnd[i] = vx + pow(-1, vx + 1);

					std::cout << "tikkum: " << vx <<  "   " << tbnd[i]  << std::endl;
					
					flag[i]   = -1;
					 
					//in_cluster[i] = ccount

					//flip = rand(Bool) 	// flip a coin for the SW cluster flip
					//    LegType[i] ⊻= 1 	// spinflip
					//}

					//vx = tbnd[i];			
					while (!zstack.empty())
					{
						
						v1 = zstack.back();
						
						v1 = X[v1];
						i = lpos[v1 / 4];
						//std::cout << X[v1] << " " << v1 << "  rann   " << r << std::endl;
						b = str[i];
						vx = tbnd[i];						
						zstack.pop_back();

						

						if (flag[i] == 0)
						{
														
							if (b >= 0 and b < sv.Nb)
							{
								//std::cout << X[v1] << " IN " << v1 << "    " << i << std::endl;
								cstack.push_front(v1);
								//flag[v1] = -1;
							}
							else
							{
								//std::cout << X[v1] << " IN " << v1 << "    " << i << std::endl;
								v = 4 *(long(v1 / 4));
								zstack.push_front(v);
								zstack.push_front(v + 1);
								zstack.push_front(v + 2);
								zstack.push_front(v + 3);
								
								flag[i] = -1;
								 

								//std::cout << "Inside: " << i <<  "   " << v1 << std::endl;
 								tbnd[i] = vx + pow(-1, vx + 1);
							}
						}
					}
				}
			}
		//}
		xstack.clear();
		zstack.clear();
		cstack.clear();
	}
	*/

	//xstack = {};

	//zstack = {};

	std::cout << " Vikas  " << std::endl;
	/////////////////////////////////////// Update spin configuration here	//////////////////////
	for (int j = 0; j < sv.Ns; ++j)
	{
		s1 = lattice[j].S();
		if (last[j] != -1)
		{
			//if (X[last[j]] == -1){	// Have to change here for xx bonds
			i = lpos[int(last[j] / 4)];
			o = tbnd[i];
			b = last[j] % 4;
			//ss1 = lattice[j].S ();
			//s1 = lattice[j].S();
			//std::cout << " Vikas  " << b << "  " << o << std::endl;
			
			lattice[j].set_S(2 *vxleg[b][o] - 1);
			/*
			if (vxleg[b][o] !=0 and vxleg[b][o] != 1){ 	std:: cout << "errrr     2" << std::endl;
				exit(1);
			}

			 */
			//std::cout << j << "    " <<  s1 << "  --- >   " << lattice[j].S() << std::endl;
			//ss2 = lattice[j].S ();	  
			//cout << "i bef   " << j << "  " << o << "  " << last[j] << "   s   " << vxleg[fspn[j]][o] << "       " << ss1 << "   -->    " << ss2 << endl; 
			//}
		}
		std::cout << "  B:A  " << j << "  " << s1 << " : " << lattice[j].S() << std::endl;
		last[j] = -1;
		frst[j] = -1;
	}

	//std::cout<<"removal 2 "<<std::endl;
	//////////////////////// printing spin configuration
	/*
	for (int i = 0; i < sv.Ns; ++i){
		std::cout<<"i >> " << i << " S = "<<(1 + lattice[i].S()) / 2<<std::endl;
	}

	*/
	////////////////////////////////////////////////////

	delete[] X;
	//delete[] tbnd;
	delete[] galf;
	delete[] lpos;
	delete[] flag;

	// End
}
