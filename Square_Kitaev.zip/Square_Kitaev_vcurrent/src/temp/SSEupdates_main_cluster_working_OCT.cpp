#include "../include/SSEvariables.hpp"
#include "../include/SSElattice.hpp"
#include "../include/SSEobservables.hpp"
#include "../include/SSEupdates.hpp"
#include <iostream>
#include <deque>
#include <numeric> // for std::accumulate
#if PARALLEL
#include <execution>
#define SEQ std::execution::seq,
#define PAR std::execution::par,
#else
#define SEQ
#define PAR
#endif


static ran rann;
using namespace std;


// Custom multiplication function



void
SSEupdates::mcstep(SSElattice * lattice, SSEvariables & sv) {
  diag_update(lattice, sv);
  looper(lattice, sv);
}



void
SSEupdates::diag_update(SSElattice *lattice, SSEvariables &sv)
{
	int b, o, ss1, ss2,vx;
	double r, p, cp;
	/*
	int dumm_latt[16];

	for (int i = 0; i < sv.Ns; ++i) {
		dumm_latt[i] = lattice[i].S();
	} 
	 */
	//std::cout<<" Lc =  "<<sv.Lc<<" n1/Beta = "<<sv.n1<<" Beta = "<<sv.Beta<<std::endl;
	// Jxx part
	for (int i = 0; i < sv.Lc; ++i)
	{
		o = str[i];
		if (o < 0)
		{
			// Identity operator
			r = rann();
			cp = 0.0;
			for (int k = 0; k < 2; k++)
			{
				// k = 0 >> Jx-bond, k = 1 >> Jz-bond.
				cp += sv.cum_prob[k];
				if (cp > r and sv.cum_prob[k] > 1e-6)
				{
					b = int(rann() *sv.Nb) + k *sv.Nb;	// b = 0 to Nb are Jx-bonds, b = Nb to 2Nb are Jz-bonds.				
					ss1 = (1 + lattice[sv.JHsites[b][0]].S()) / 2;
					ss2 = (1 + lattice[sv.JHsites[b][1]].S()) / 2;
					p = (1 - k) + k *awgt[ss1][ss2];	// for inserting a Jz- diagonal operator, both spins should be same. 

					p = p *sv.prob_in / float(sv.Lc - sv.n1);	// prob. of inserting a diagonal operator
					if (rann() < p)
					{
						str[i] = b;
						tbnd[i] = legvx[ss1][ss2][ss1][ss2];
						sv.n1 += 1;
					}
					break;
				}
			}
		}
		else
		{
			vx = tbnd[i];
			if (vxoper[vx] == 1)	// its a diagonal operator.
			{
				p = sv.prob_rm* float(sv.Lc - sv.n1 + 1);	// prob. of removing a diagonal operator
				if (rann() < p)
				{
					str[i] = -1;
					tbnd[i] = -1;
					sv.n1 -= 1;
				}
			}
			else if (vxoper[vx] == 2)
			{
				// its a off-diagonal operator (Jx-operator)
				ss1 = sv.JHsites[o][0];
				ss2 = sv.JHsites[o][1];
				lattice[ss1].set_S(2 *vxleg[2][vx] - 1);
				lattice[ss2].set_S(2 *vxleg[3][vx] - 1);
			}
			else
			{
			 	//std::cout << ("Error in vr type!") << std::endl;
				exit(1);
			}
		}
	}






//	for (int i = 0; i < sv.Lc; ++i)
//	{
//		o = str[i];
//		//t = tbnd[i];
//		if (o < 0)
//		{
//			// it's an Identity operator
//			//std::cout<<"enter"<<std::endl;
//			b = int(rann() *sv.Nb);	// bond number from 0 to Nb are Jx-bonds.
//			ss1 = (1 + lattice[sv.JHsites[b][0]].S()) / 2;
//			ss2 = (1 + lattice[sv.JHsites[b][1]].S()) / 2;
//			p = sv.prob_in1 / float(sv.Lc - sv.n1);	// prob. of inserting a diagonal operator
//			//std::cout<<"insert "<<sv.prob_in[0]<<"   "<< float(sv.Lc - sv.n1 )<<std::endl;
//			if (rann() < p)	// Bond
//			{
//				str[i] = b;
//        tbnd[i] = legvx[ss1][ss2][ss1][ss2];
//				sv.n1 += 1;
//			}
//		}
//		else if (o >= 0 and o < sv.Nb)
//		{
//      vx = tbnd[i];
//			if (vxoper[vx] == 1)
//			{
//				// operator is of diagonal type. No restriction on spin configuration.
//				p = sv.prob_rm1 *float(sv.Lc - sv.n1 + 1);	// prob. of deleting a diagonal operator
//				//std::cout<<"removal "<<random_n<<"   "<<p<<std::endl;
//				if (rann() < p)
//				{
//					str[i] = -1;
//					sv.n1 -= 1;
//					//std::cout<<"T = "<<i<<"  removal >>"<<"Lc  = "<<sv.Lc<<"  n1  = "<<sv.n1<<std::endl;
//				}
//			else if (vxoper[vx] == 2)
//			{
//				// its a off-diagonal operator (Jx-operator)
//				ss1 = sv.JHsites[o][0];
//				ss2 = sv.JHsites[o][1];
//				lattice[ss1].set_S(2 *vxleg[2][vx] - 1);
//				lattice[ss2].set_S(2 *vxleg[3][vx] - 1);
//			}
//			else
//			{
//			 	////std::cout << ("Error in vr type!") << std::endl;
//				exit(1);
//			}
//			}
//		}
//	}

//	// Jzz part
//	for (int i = 0; i < sv.Lc; ++i)
//	{
//		o = str[i];
//		//t = tbnd[i];
//		if (o < 0)
//		{
//			// it's an Identity operator
//			//std::cout<<"enter"<<std::endl;
//			b = int(rann() *sv.Nb) + sv.Nb;	// bond number from 0 to Nb are Jx-bonds.
//			ss1 = (1 + lattice[sv.JHsites[b][0]].S()) / 2;
//			ss2 = (1 + lattice[sv.JHsites[b][1]].S()) / 2;
//			p = awgt[ss1][ss2];
//			p = p *sv.prob_in2 / float(sv.Lc - sv.n1);	// prob. of inserting a diagonal operator
//			//std::cout<<"insert "<<sv.prob_in[0]<<"   "<< float(sv.Lc - sv.n1 )<<std::endl;
//			if (rann() < p)	// Bond
//			{
//				str[i] = b;
//				sv.n1 += 1;
//        tbnd[i] = legvx[ss1][ss2][ss1][ss2];
//			}
//		}
//		else if (o >= sv.Nb)
//		{
//      vx = tbnd[i];
//			if (vxoper[vx] == 1)
//			{
//				// operator is of diagonal type. No restriction on spin configuration.
//				p = sv.prob_rm2 *float(sv.Lc - sv.n1 + 1);	// prob. of deleting a diagonal operator
//				//std::cout<<"removal "<<random_n<<"   "<<p<<std::endl;
//				if (rann() < p)
//				{
//					str[i] = -1;
//					sv.n1 -= 1;
//					//std::cout<<"T = "<<i<<"  removal >>"<<"Lc  = "<<sv.Lc<<"  n1  = "<<sv.n1<<std::endl;
//				}
//			}
//		}
//	}





	/*
	str[4] = 2 + sv.Nb;
	sv.n1 = 1;
	//std::cout<<"   "<<sv.JHsites[1+sv.Nb][0]<<"   >>"<<sv.JHsites[1+sv.Nb][1]<<"  n1  = "<<sv.n1<<std::endl;
	
	str[9] = 5 + sv.Nb;
	sv.n1 += 1;

	str[11] = 8 + sv.Nb;
	sv.n1 += 1;		
	*/

}





//void
//SSEupdates::diag_update(SSElattice * lattice, SSEvariables & sv) {
//  int b, o, ss1, ss2, vx;
//  double p, r, cp;

//  /*
//  int dumm_latt[9];

//  for (int i = 0; i < sv.Ns; ++i) {
//  	dumm_latt[i] = lattice[i].S();
//  	//////std::cout << lattice[i].S();
//  } 
//  */

//  for (int i = 0; i < sv.Lc; ++i) {
//    o = str[i];
//    if (o < 0) {
//      // Identity operator
//      r = rann();
//      cp = 0.0;
//      for (int k = 0; k < 2; k++) {
//        // k = 0 >> Jx-bond, k = 1 >> Jz-bond.
//        cp += sv.cum_prob[k];
//        if (cp > r and sv.cum_prob[k] > 1e-6) {
//          b = int(rann() * sv.Nb) + k * sv.Nb; // b = 0 to Nb are Jx-bonds, b = Nb to 2Nb are Jz-bonds.				
//          ss1 = (1 + lattice[sv.JHsites[b][0]].S()) / 2;
//          ss2 = (1 + lattice[sv.JHsites[b][1]].S()) / 2;
//          p = (1 - k) + k * awgt[ss1][ss2]; // for inserting a Jz- diagonal operator, both spins should be same. 
//          p = p * sv.prob_in / float(sv.Lc - sv.n1); // prob. of inserting a diagonal operator
//          if (rann() < p)
//          {
//            str[i] = b;
//            tbnd[i] = legvx[ss1][ss2][ss1][ss2];
//            sv.n1 += 1;
//            break;
//          }
//        }
//      }
//    } else {
//      vx = tbnd[i];
//      if (vxoper[vx] == 1) // its a diagonal operator.
//      {
//        p = sv.prob_rm * float(sv.Lc - sv.n1 + 1); // prob. of removing a diagonal operator
//        if (rann() < p) {
//          str[i] = -1;
//          tbnd[i] = -1;
//          sv.n1 -= 1;
//        }
//      } else if (vxoper[vx] == 2) {
//        // its a off-diagonal operator (Jx-operator)
//        ss1 = sv.JHsites[o][0];
//        ss2 = sv.JHsites[o][1];
//        lattice[ss1].set_S(2 * vxleg[2][vx] - 1);
//        lattice[ss2].set_S(2 * vxleg[3][vx] - 1);
//      } else {
//        ////std::cout << ("Error in vr type!") << std::endl;
//        exit(1);
//      }
//    }
//  }

////  int i;

////  i = 2;
////  b = 7;
////  str[i] = b;
////  lattice[sv.JHsites[b][0]].set_S(1);
////  lattice[sv.JHsites[b][1]].set_S(-1);
////  ss1 = (1 + lattice[sv.JHsites[b][0]].S()) / 2;
////  ss2 = (1 + lattice[sv.JHsites[b][1]].S()) / 2;
////  tbnd[i] = legvx[ss1][ss2][ss1][ss2];

////  i = 16;
////  b = 7;
////  str[i] = b;
////  lattice[sv.JHsites[b][0]].set_S(1);
////  lattice[sv.JHsites[b][1]].set_S(-1);
////  ss1 = (1 + lattice[sv.JHsites[b][0]].S()) / 2;
////  ss2 = (1 + lattice[sv.JHsites[b][1]].S()) / 2;
////  tbnd[i] = legvx[ss1][ss2][ss1][ss2];

////  i = 19;
////  b = 17;
////  str[i] = b;
////  lattice[sv.JHsites[b][0]].set_S(-1);
////  lattice[sv.JHsites[b][1]].set_S(-1);
////  ss1 = (1 + lattice[sv.JHsites[b][0]].S()) / 2;
////  ss2 = (1 + lattice[sv.JHsites[b][1]].S()) / 2;
////  tbnd[i] = legvx[ss1][ss2][ss1][ss2];

////  sv.n1 = 3;
//}

void
SSEupdates::looper(SSElattice * lattice, SSEvariables & sv) {
  int o, v, vi, v0, v1, v2;
  int vx, ic, oc;
  int s1, s2;//, ss1, ss2, tt1, tt2;
  int b;
  double r, p;

  int * X = new int[4 * sv.n1]; // Linked-list
  bool * flag = new bool[4 * sv.n1];
  bool * galf = new bool[sv.Lc];
  bool * galf1 = new bool[sv.Lc];
  int * lpos = new int[sv.Lc]; // store positions of non-identity operator in the operator string of length Lc.

  //////////////////////////////////////////// Linked list construction	///////////////////////////////
  v0 = 0;
  for (int i = 0; i < sv.Lc; ++i) {
    b = str[i];
    if (b >= 0) // there is a non-identity operator.
    {
      s1 = sv.JHsites[b][0];
      s2 = sv.JHsites[b][1];
      v1 = last[s1];
      v2 = last[s2];

      lpos[int(v0 / 4)] = i;
      galf[i] = 0;
      galf1[i] = 0;
      //std::cout << "timsl:: " << i << "  " << "sitesss    " << s1 << " " << s2 << "  :: " << "  type: " << int(b / sv.Nb) << " which vertex: " << tbnd[i] << std::endl;
      if (v1 != -1) {
        X[v1] = v0;
        X[v0] = v1;
      } else {
        frst[s1] = v0;
      }

      if (v2 != -1) {
        X[v2] = v0 + 1;
        X[v0 + 1] = v2;
      } else {
        frst[s2] = v0 + 1;
      }

      last[s1] = v0 + 2;
      last[s2] = v0 + 3;
      flag[v0] = 0;
      flag[v0 + 1] = 0;
      flag[v0 + 2] = 0;
      flag[v0 + 3] = 0;
      v0 += 4;
    }
  }

  // PBC loops 
  for (int k = 0; k < sv.Ns; ++k) {
    v1 = frst[k];
    if (v1 != -1) {
      v2 = last[k];
      X[v2] = v1;
      X[v1] = v2;
    }
  }

  //for (int k = 0; k < v0; ++k)//std::cout << k << "------>" << X[k] << std::endl;

  //std::cout << std::endl;



//  auto customMultiply = [flag](bool accumulator, int element) {
//      return accumulator && flag[element] && flag[element+1] && flag[element+2] && flag[element+3];
//  };



  nl = 10*sv.lx; //10 * sv.lx;
  //bool des=1, sp1,sp2,sp3,sp4;
  int i, l, vxi;
  if (v0 != 0) {
    deque < int > cstack;//, astack, xstack;//, zstack;
    
    for (int j = 0; j < nl; j++) {
      v1 = int(rann() * v0);

      // xx caretaker
      ic = v1 % 4;
      i = lpos[v1 / 4];
      b = str[i];
      if (b >= 0 and b < sv.Nb) {
        //std::cout << " vi " << " = " << v1  << std::endl;
        vi = v1;
        //if (flag[v1] == 0){
        while (1) {
          ic = v1 % 4;
          i = lpos[v1 / 4];
          b = str[i];
          v = 4 * (int(v1 / 4));            
          ////std::cout << " Vx: " << v1  << "  " << i << " -> " << tbnd[i] << std::endl;
          if (int(b/sv.Nb) < 1) {
            vx = tbnd[i];
            p = 0;
            r = rann();
            for (oc = 0; oc < 4; ++oc) {
              p += vxprb[oc][ic][vx];
              if (r < p) {
                tbnd[i] = vxnew[oc][ic][vx];
                break;
              }
            }
            //if (galf[i]==0)xstack.push_front(v);
            //des = 0;
            // 1 = True // 0 = False 
          } else {
            oc = ic;//3 - ic;//ic + 2*pow(-1,1+(1-int(ic/2))); //ic int(rann()* 4);
            //i = lpos[v1/4];
            //vx = tbnd[i];
            //l = v1 + pow(-1, v1);
            //if (galf[i] == 0) {cstack.push_front(l); astack.push_front(v);}
            //des = des*1;
            //tbnd[i] = vxnew[oc][ic][vx];
          }
          v2 = v + oc;
          //flag[v1] = !flag[v1];
          //flag[v2] = !flag[v2];
          //galf[i] = 1;
          //std::cout << "T: " << i << "  " << " V1--v2--X[v2] =       " << v1 << " -  " << v2 << "  --  " << X[v2] << "  type: " << int(b / sv.Nb) << " which vertex: " << tbnd[i] <<std::endl;          
          v1 = X[v2];
          if (v1 == vi or v2 == vi) break;
        }
      }
        //}
        //std::cout << std::endl;
        //}
      else {

        // zz caretaker
        vxi = tbnd[i];
        cstack.push_front(v1);
        while (!cstack.empty()) 
        {
          v1 = cstack.back();
          cstack.pop_back();
          i = lpos[v1 / 4];
          b = str[i];
          //std::cout << " vi " << " = " << v1  << std::endl;
          vi = v1;
          ////std::cout << " Vx: " << v1 << "  " << i << " -> " << tbnd[i] << std::endl;
          if (flag[v1] == 0){
            while (1) {
              ic = v1 % 4;
              i = lpos[v1 / 4];
              b = str[i];
              v = 4 * (int(v1 / 4));
              vx = tbnd[i];
              l = v1 + pow(-1, v1);
//              if (flag[v1] == flag[] or int(b/sv.Nb) < 1) vx = tbnd[i]; 
              if (galf[i] == 1)vx = vx + pow(-1,vx+1);              
              if (vx == vxi or int(b/sv.Nb) < 1){ 
                oc = 3 - ic;//ic + 2*pow(-1,1+(1-int(ic/2))); //ic int(rann()* 4);
                //i = lpos[v1/4];

                if (galf[i] == 0) {cstack.push_front(l); tbnd[i] = vx + pow(-1,vx+1);}
                  //des = des*1;

//              }
                v2 = v + oc;
                flag[v1] = !flag[v1];
                flag[v2] = !flag[v2];
                galf[i] = 1;
          
                //std::cout << "T: " << i << "  " << " V1--v2--X[v2] =       " << v1 << " -  " << v2 << "  --  " << X[v2] << "  type: " << int(b / sv.Nb) << " which vertex: " << tbnd[i] <<std::endl;          
                v1 = X[v2];
                if (v1 == vi or v2 == vi) break;
              } else {
                break;
              }
          }
        }
          //std::cout << std::endl;
        }
        cstack.clear();
      }




//      des = std::accumulate(astack.begin(), astack.end(), 1, customMultiply);


////      //std::cout << des << std::endl;
//      if (des==1){
//        while (!astack.empty())  
//          {
//            v = astack.back();
//            astack.pop_back();
//            i = lpos[v / 4];
//            vx = tbnd[i];
//            //std::cout << "bnd " <<  i << "  vx  " << vx  << std::endl;
//		        //sp1 = vxleg[0][vx]; if(flag[v]==1) sp1 = !sp1;
//            //sp2 = vxleg[1][vx]; if(flag[v+1]==1) sp2 = !sp2;
//            //sp3 = vxleg[2][vx]; if(flag[v+2]==1) sp3 = !sp3;
//            //sp4 = vxleg[3][vx]; if(flag[v+3]==1) sp4 = !sp4;
//            ////std::cout << sp1 << sp2 << sp3 << sp4 << std::endl;
//				    tbnd[i] = vx + pow(-1, vx + 1); //legvx[sp1][sp2][sp3][sp4];
//          }
////      while (!xstack.empty())  
////        {
////          v = xstack.back();
////          xstack.pop_back();
////          i = lpos[v / 4];
////          vx = tbnd[i];
////          //std::cout << "bnd " <<  i << "  vx  " << vx  << std::endl;
////		      sp1 = vxleg[0][vx]; if(flag[v]==1) sp1 = !sp1;
////          sp2 = vxleg[1][vx]; if(flag[v+1]==1) sp2 = !sp2;
////          sp3 = vxleg[2][vx]; if(flag[v+2]==1) sp3 = !sp3;
////          sp4 = vxleg[3][vx]; if(flag[v+3]==1) sp4 = !sp4;
////          //std::cout << sp1 << sp2 << sp3 << sp4 << std::endl;
////				  tbnd[i] = legvx[sp1][sp2][sp3][sp4];
////        }
//      }

      //astack.clear();
      //xstack.clear();
    }
  }




  /////////////////////////////////////// Update spin configuration here	//////////////////////
  for (int j = 0; j < sv.Ns; ++j) {
    if (last[j] != -1) {
      i = lpos[int(last[j] / 4)];
      o = tbnd[i];
      b = last[j] % 4;

      //ss1 = lattice[j].S();
      lattice[j].set_S(2 * vxleg[b][o] - 1);
      //ss2 = lattice[j].S();

      //std::cout << ss1 << " -->  " << ss2 << "  site:  " << j << std::endl;

    } else {
      // flip isolated spins with prob half.
      //ss1 = lattice[j].S();
      if (rann() < 0.5) lattice[j].flip();
      //ss1 = lattice[j].S();
    }

    last[j] = -1;
    frst[j] = -1;
  }
  ////std::cout << std::endl;
  delete[] X;
  delete[] flag;
  delete[] galf;
  delete[] galf1;
  delete[] lpos;
}



/*


  nl = 10*sv.lx; //10 * sv.lx;
  //bool des=1, sp1,sp2,sp3,sp4;
  int i, l, vxi;
  if (v0 != 0) {
    deque < int > cstack;//, astack, xstack;//, zstack;
    
    for (int j = 0; j < nl; j++) {
      v1 = int(rann() * v0);

      // xx caretaker
      ic = v1 % 4;
      i = lpos[v1 / 4];
      b = str[i];
      if (b >= 0 and b < sv.Nb) {
        //std::cout << " vi " << " = " << v1  << std::endl;
        vi = v1;
        //if (flag[v1] == 0){
        while (1) {
          ic = v1 % 4;
          i = lpos[v1 / 4];
          b = str[i];
          v = 4 * (int(v1 / 4));            
          ////std::cout << " Vx: " << v1  << "  " << i << " -> " << tbnd[i] << std::endl;
          if (int(b/sv.Nb) < 1) {
            vx = tbnd[i];
            p = 0;
            r = rann();
            for (oc = 0; oc < 4; ++oc) {
              p += vxprb[oc][ic][vx];
              if (r < p) {
                tbnd[i] = vxnew[oc][ic][vx];
                break;
              }
            }
            //if (galf[i]==0)xstack.push_front(v);
            //des = 0;
            // 1 = True // 0 = False 
          } else {
            oc = ic;//3 - ic;//ic + 2*pow(-1,1+(1-int(ic/2))); //ic int(rann()* 4);
            //i = lpos[v1/4];
            //vx = tbnd[i];
            //l = v1 + pow(-1, v1);
            //if (galf[i] == 0) {cstack.push_front(l); astack.push_front(v);}
            //des = des*1;
            //tbnd[i] = vxnew[oc][ic][vx];
          }
          v2 = v + oc;
          //flag[v1] = !flag[v1];
          //flag[v2] = !flag[v2];
          //galf[i] = 1;
          //std::cout << "T: " << i << "  " << " V1--v2--X[v2] =       " << v1 << " -  " << v2 << "  --  " << X[v2] << "  type: " << int(b / sv.Nb) << " which vertex: " << tbnd[i] <<std::endl;          
          v1 = X[v2];
          if (v1 == vi or v2 == vi) break;
        }
      }
        //}
        //std::cout << std::endl;
        //}
      else {

        // zz caretaker
        vxi = tbnd[i];
        cstack.push_front(v1);
        while (!cstack.empty()) 
        {
          v1 = cstack.back();
          cstack.pop_back();
          i = lpos[v1 / 4];
          b = str[i];
          //std::cout << " vi " << " = " << v1  << std::endl;
          vi = v1;
          ////std::cout << " Vx: " << v1 << "  " << i << " -> " << tbnd[i] << std::endl;
          if (flag[v1] == 0){
            while (1) {
              ic = v1 % 4;
              i = lpos[v1 / 4];
              b = str[i];
              v = 4 * (int(v1 / 4));
              vx = tbnd[i];
              l = v1 + pow(-1, v1);
//              if (flag[v1] == flag[] or int(b/sv.Nb) < 1) vx = tbnd[i]; 
              if (galf[i] == 1)vx = vx + pow(-1,vx+1);              
              if (vx == vxi or int(b/sv.Nb) < 1){ 
                oc = 3 - ic;//ic + 2*pow(-1,1+(1-int(ic/2))); //ic int(rann()* 4);
                //i = lpos[v1/4];

                if (galf[i] == 0) {cstack.push_front(l); tbnd[i] = vx + pow(-1,vx+1);}
                  //des = des*1;

//              }
                v2 = v + oc;
                flag[v1] = !flag[v1];
                flag[v2] = !flag[v2];
                galf[i] = 1;
          
                //std::cout << "T: " << i << "  " << " V1--v2--X[v2] =       " << v1 << " -  " << v2 << "  --  " << X[v2] << "  type: " << int(b / sv.Nb) << " which vertex: " << tbnd[i] <<std::endl;          
                v1 = X[v2];
                if (v1 == vi or v2 == vi) break;
              } else {
                break;
              }
          }
        }
          //std::cout << std::endl;
        }
        cstack.clear();
      }




//      des = std::accumulate(astack.begin(), astack.end(), 1, customMultiply);


////      //std::cout << des << std::endl;
//      if (des==1){
//        while (!astack.empty())  
//          {
//            v = astack.back();
//            astack.pop_back();
//            i = lpos[v / 4];
//            vx = tbnd[i];
//            //std::cout << "bnd " <<  i << "  vx  " << vx  << std::endl;
//		        //sp1 = vxleg[0][vx]; if(flag[v]==1) sp1 = !sp1;
//            //sp2 = vxleg[1][vx]; if(flag[v+1]==1) sp2 = !sp2;
//            //sp3 = vxleg[2][vx]; if(flag[v+2]==1) sp3 = !sp3;
//            //sp4 = vxleg[3][vx]; if(flag[v+3]==1) sp4 = !sp4;
//            ////std::cout << sp1 << sp2 << sp3 << sp4 << std::endl;
//				    tbnd[i] = vx + pow(-1, vx + 1); //legvx[sp1][sp2][sp3][sp4];
//          }
////      while (!xstack.empty())  
////        {
////          v = xstack.back();
////          xstack.pop_back();
////          i = lpos[v / 4];
////          vx = tbnd[i];
////          //std::cout << "bnd " <<  i << "  vx  " << vx  << std::endl;
////		      sp1 = vxleg[0][vx]; if(flag[v]==1) sp1 = !sp1;
////          sp2 = vxleg[1][vx]; if(flag[v+1]==1) sp2 = !sp2;
////          sp3 = vxleg[2][vx]; if(flag[v+2]==1) sp3 = !sp3;
////          sp4 = vxleg[3][vx]; if(flag[v+3]==1) sp4 = !sp4;
////          //std::cout << sp1 << sp2 << sp3 << sp4 << std::endl;
////				  tbnd[i] = legvx[sp1][sp2][sp3][sp4];
////        }
//      }

      //astack.clear();
      //xstack.clear();
    }
  }




*/




/*

            // Second time for trigger 
            // case 1: time slice = visited, vx leg =  not visited, nbr vx = leg visited;					    
//            if (galf[i] == 1 and flag[l] == 1 and flag[v1] == 0) {
//              tbnd[i] = vxnew[oc][ic][vx];
//              flag[v1] = !flag[v1];
//              flag[v2] = !flag[v2];
//              //galf1[i] = !galf1[i];
//            }
//            // First time;
//            // case 2: time slice = not visited;
//            else if (galf[i] == 0) {
//              tbnd[i] = vxnew[oc][ic][vx];
//              flag[v1] = !flag[v1];
//              flag[v2] = !flag[v2];
//              //galf1[i] = !galf1[i];
//            }
            // Retraction;
            // case 3: time slice = visited, vx leg =  not visited, nbr vx = leg visited;					    
//            else if (galf[i] == 1 and flag[l] == 0 and flag[v1] == 1) {
//              tbnd[i] = vxnew[oc][ic][vx];
//              flag[v1] = !flag[v1];
//              flag[v2] = !flag[v2];
//              //galf1[i] = !galf1[i];
//            }

//            else if (galf[i] == 1 and flag[l] == 1 and flag[v1] == 1) {
//              tbnd[i] = vxnew[oc][ic][vx];
//              flag[v1] = !flag[v1];
//              flag[v2] = !flag[v2];
//              //galf1[i] = !galf1[i];
//            }
//			      // case 4 : visited vertex, but retracted one vx, so both not visited again; 
//            else if (galf[i] == 1 and flag[l] == 0 and flag[v1] == 0) {
//              tbnd[i] = vxnew[oc][ic][vx];
//			        cstack.push_front(l);
//              flag[v1] = !flag[v1];
//              flag[v2] = !flag[v2];
//              //galf1[i] = !galf1[i];
//            }		

*/







/*
			    else
			    {
			     	////std::cout << "here  " << std::endl;
                    if(!flag[v1])zstack.push_front(v1);
				    v = 4 *(int(v1 / 4));
				    zstack.push_front(v);
				    zstack.push_front(v + 1);
				    zstack.push_front(v + 2);
				    zstack.push_front(v + 3);

				    i  = lpos[v1 / 4];
				    vx = tbnd[i];
				    if (r > 0.5 and flag[v])tbnd[i] = vx + pow(-1, vx + 1);

				    //std::cout  << "tikkum: " << i << "     " << vx << "   " << tbnd[i] << std::endl;

				    galf[i] = -1;
				    //in_cluster[i] = ccount



				    //vx = tbnd[i];			
				    while (!zstack.empty())
				    {
					    v1 = zstack.back();
                        v = v1;
                        ////std::cout << " Vx: " << v1  << " -->  " << v2 << "  : Link to  " << v << std::endl;
					    i = lpos[v1 / 4];
					    ////std::cout << X[v1] << " " << v1 << "  rann   " << r << std::endl;
					    b = str[i];
					    vx = tbnd[i];
					    zstack.pop_back();

					    if (!galf[i] and !flag[v1])
					    {
						    if (b >= 0 and b < sv.Nb)
						    {
						     	////std::cout << X[v1] << " IN " << v1 << "    " << i << std::endl;
                                //std::cout << " c in z time: " << i  << " -->  " << v << "  : Link to  " << v1 << std::endl;
							    cstack.push_front(v1);
                                //galf[i] = -1;
                                //break;
							    //flag[v1] = -1;
						    }
						    else
						    {
                                //std::cout << " time: " << i  << " -->  " << v << "  : Link to  " << v1 << std::endl;
						     	////std::cout << X[v1] << " IN " << v1 << "    " << i << std::endl;
							    v = 4 *(int(v1 / 4));
							    zstack.push_front(v);
							    zstack.push_front(v + 1);
							    zstack.push_front(v + 2);
							    zstack.push_front(v + 3);

							    galf[i] = true;
							    ////std::cout << "Inside: " << i <<  "   " << v1 << std::endl;
							    if (r > 0.5)tbnd[i] = vx + pow(-1, vx + 1);
						    }
					    }
					    v1 = X[v1];
				    }
			    }
*/

/*

      nl = 10*sv.lx;
      int i;
      int l;
	    
      for (int j = 0; j < nl; j++) {
        vi = int(rann() * v0);
        v1 = vi;
          // time-slice number
		    if (v0!=0){   // v0 != 0  if there is atleast one non-identity operator in the operator string.
		      while (1) {
		        ic = v1 % 4;
                i = lpos[v1/4]; 
		        b = str[i];
		        if (b >= 0 and b < sv.Nb){    // its a Jx -vertex
		          r = rann();
		          vx = tbnd[i];
		          p = 0;
		          for (oc = 0; oc < 4; ++oc) {
		            p += vxprb[oc][ic][vx];
		            if (r < p) {
		              tbnd[i] = vxnew[oc][ic][vx];
		              break;
		            }
		          }
		        } else{       // its a Jz - vertex
				    oc = ic; // bounce with prob 1.
			    }
		        v2 = 4 * (int(v1 / 4)) + oc;
		        v1 = X[v2];
		        if (v1 == vi or v2 == vi) break;
		      }
		    }
      }
    */
