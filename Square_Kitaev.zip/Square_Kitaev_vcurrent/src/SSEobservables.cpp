#include "../include/SSElattice.hpp"
#include "../include/SSEvariables.hpp"
#include "../include/SSEobservables.hpp"
#include "../include/SSEupdates.hpp"
#include <iostream>
#include <iomanip>

using namespace std;


void
SSEobservables::measurements(SSEvariables sv, SSElattice* lattice)
{
	// Observables
  enrg_time = -float(sv.n1)/sv.Beta/sv.Ns; // time series energy 
	enrg_bin += enrg_time/sv.iter; // avg energy 
  
	magZ_square_time = magnetization(sv, lattice); // time series mag^2
  magZ_square_bin += magZ_square_time/sv.iter; // avg mag^2

  ZZCorrelation(sv, lattice);
}


///////////////////////////////////////////////////////////////////////////////////////

double
SSEobservables::magnetization(SSEvariables sv, SSElattice* lattice)
{
	double m = 0;
	for (int i=0; i < sv.Ns; ++i)
	{
	    m += lattice[i].S()/double(sv.Ns);
  }
  return pow(float(m),2);
}

// Calculate S^z_i S^z_j correlation function with respect to the reference site at index 0
void
SSEobservables::ZZCorrelation(SSEvariables sv, SSElattice* lattice) {
    int referenceSpin = lattice[0].S();

    for (int j = 0; j < sv.Ns; ++j) {
        szsz[j] += static_cast<double>(referenceSpin * lattice[j].S())/sv.iter;
    }
}


void
SSEobservables::Initiate_observables(SSEvariables sv)
{
	enrg_bin = 0.;
	magZ_square_bin = 0.;
  szsz = new double[sv.Ns];
  std::fill(szsz, szsz + sv.Ns, 0);
}


