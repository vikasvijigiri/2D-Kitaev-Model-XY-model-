#include "../include/SSEvariables.hpp"
#include "../include/SSElattice.hpp"
#include "../include/SSEobservables.hpp"
#include "../include/SSEupdates.hpp"


#include <iostream>

static ran rann;
using namespace std;

//********************************************************************************************

void
SSEupdates::checkl(SSEvariables& sv)
{
	int Lc_new = int(sv.n1 + sv.n1 / 3);

	if (Lc_new > sv.Lc)
	{
		int *tmp;
    tmp = new int [Lc_new];
		int *tbnd_tmp;
    tbnd_tmp = new int [Lc_new];

		for (int i = 0; i < Lc_new; ++i){
			if (i < sv.Lc)
			{
				tmp[i] = str[i];
				tbnd_tmp[i] = tbnd[i];
			}
			else
			{
				tmp[i] = -1;
				tbnd_tmp[i] = -1;
			}
		}

		delete[] str;
		delete[] tbnd;


		// Allot values to newly created arrays.
		sv.Lc = Lc_new;
		str = new int [sv.Lc];
		tbnd = new int [sv.Lc];

		for (int i = 0; i < sv.Lc; ++i){
			str[i] = tmp[i];
			tbnd[i] = tbnd_tmp[i];
		}
		delete[] tmp;
		delete[] tbnd_tmp;
		//std::cout << "Lc = " << sv.Lc <<  std::endl;
	}
}


//********************************************************************************************

void
SSEupdates::initvrtx_dirloop()
{

	int v0, v1, v2, v3, v4, v5, v6, v7;

	int vx, ic, oc, vxn;
	int st[4];

	// Define legvx, vxoper, vxwgt, and vxleg
	v0 = 1;
	v1 = v0 + 1;
	v2 = v0 + 2;
	v3 = v0 + 3;
	v4 = v0 + 4;
	v5 = v0 + 5;
	v6 = v0 + 6;
	v7 = v0 + 7;

	for (int t2 = 0; t2 < 2; ++t2)
	{
		for (int t1 = 0; t1 < 2; ++t1)
		{
			for (int s2 = 0; s2 < 2; ++s2)
			{
				for (int s1 = 0; s1 < 2; ++s1)
				{
					legvx[s1][s2][t1][t2] = 0;
				}
			}
		}
	}
	// ss1 ss2 ---> tt1 tt2
	legvx[1][0][0][1] = v0;	//offdiagonal  1
	legvx[0][1][1][0] = v1;	//offdiagonal  2
	legvx[1][1][0][0] = v2;	//offdiagonal  3
	legvx[0][0][1][1] = v3;	//offdiagonal  4
	legvx[1][0][1][0] = v4;	//diagonal     5
	legvx[0][1][0][1] = v5;	//diagonal     6
	legvx[0][0][0][0] = v6;	//diagonal     7
	legvx[1][1][1][1] = v7;	//diagonal     8


	vxoper[v0] = 2;	//offdiagonal
	vxoper[v1] = 2;	//offdiagonal
	vxoper[v2] = 2;	//offdiagonal
	vxoper[v3] = 2;	//offdiagonal
	vxoper[v4] = 1;	//diagonal
	vxoper[v5] = 1;	//diagonal
	vxoper[v6] = 1;	//diagonal
	vxoper[v7] = 1;	//diagonal      

	for (int t2 = 0; t2 < 2; ++t2)
	{
		for (int t1 = 0; t1 < 2; ++t1)
		{
			for (int s2 = 0; s2 < 2; ++s2)
			{
				for (int s1 = 0; s1 < 2; ++s1)
				{
					vx = legvx[s1][s2][t1][t2];
					if (vx != 0)
					{
						vxleg[0][vx] = s1;
						vxleg[1][vx] = s2;
						vxleg[2][vx] = t1;
						vxleg[3][vx] = t2;
					}
				}
			}
		}
	}

	// Create vxnew links from input channel (ic) ---> output channel (oc).
	for (vx = 1; vx <= nvx; ++vx)
	{
		for (ic = 0; ic < 4; ++ic)
		{
			for (oc = 0; oc < 4; ++oc)
			{
				st[0] = vxleg[0][vx];
				st[1] = vxleg[1][vx];
				st[2] = vxleg[2][vx];
				st[3] = vxleg[3][vx];
				st[ic] = 1 - st[ic];
				st[oc] = 1 - st[oc];
				vxn = legvx[st[0]][st[1]][st[2]][st[3]];
				if (vxn != 0)
				{
					vxnew[oc][ic][vx] = vxn;
				}
			}
		}
	}

	// Initialize cumulative probabilities saving in vxprob.
	for (vx = 1; vx <= nvx; ++vx)
	{
		st[0] = 2*vxleg[0][vx]-1;
		st[1] = 2*vxleg[1][vx]-1;
		st[2] = 2*vxleg[2][vx]-1;
		st[3] = 2*vxleg[3][vx]-1;
		if (st[0]*st[2] == st[1]*st[3]){
			//std::cout << st[0] << "  " << st[1] << "  " << st[2] << "  " << st[3] << std::endl;
			for (ic = 0; ic < 4; ++ic){
				for (oc = 0; oc < 4; ++oc){
						if (ic != oc){
							vxprb[oc][ic][vx] = 1.0/3.0;
						} else {
							vxprb[oc][ic][vx] = 0.0;  // bounce
						}
				}
			}
		} else {
			for (ic = 0; ic < 4; ++ic){
				for (oc = 0; oc < 4; ++oc){
							vxprb[oc][ic][vx] = 0.0;  // 0 matrix element
				}
			}
		}
	}

}


//********************************************************************************************
void
SSEupdates::weights()
{
	for (int s2 = 0; s2 < 2; ++s2)
	{
		for (int s1 = 0; s1 < 2; ++s1)
		{
			wgt[s1][s2] = 2.0 * 0.25 * pow(-1, 1+s1) *pow(-1, s2);
			//std::cout<<" s1 = "<<s1<<" s2 = "<<s2<<" wgt[s1][s2] = "<<wgt[s1][s2]<<std::endl;
			//std::cout<<" amax = "<<amax<<std::endl;
			if (wgt[s1][s2] > amax)
				amax = wgt[s1][s2];
		}
	}

	for (int s2 = 0; s2 < 2; ++s2)
	{
		for (int s1 = 0; s1 < 2; ++s1)
		{
			wgt[s1][s2] = amax - wgt[s1][s2];
		}
	}

	for (int s2 = 0; s2 < 2; ++s2)
	{
		for (int s1 = 0; s1 < 2; ++s1)
		{
			awgt[s1][s2] = wgt[s1][s2];
			if (awgt[s1][s2] > 1e-6)
			{
				dwgt[s1][s2] = 1.0 / awgt[s1][s2];
			}
			else
			{
				dwgt[s1][s2] = 1.e6;
			}
		}
	}
	//std::cout<<wgt[1][1] << wgt[0][0] << wgt[0][1] << wgt[1][0] <<std::endl;
	//std::cout<<awgt[1][1] << awgt[0][0] << awgt[0][1] << awgt[1][0] <<std::endl;
	//std::cout<<dwgt[1][1] << dwgt[0][0] << dwgt[0][1] << dwgt[1][0] <<std::endl;
}


void
SSEupdates::initialize(SSEvariables& sv)
{
	//std::cout << sv.Lc << "  " << sv.n1 << std::endl;
	// H-bond part
	str = new int [sv.Lc];
	tbnd = new int [sv.Lc];
	for (int j = 0; j < sv.Lc; j++)
	{
		str[j] = -1; tbnd[j] = -1; 
		
	}

	frst = new int[sv.Ns];
	last = new int[sv.Ns];
	
	for (int i = 0; i < sv.Ns; i++)
	{
		frst[i] = -1;
		last[i] = -1;
	}
}

