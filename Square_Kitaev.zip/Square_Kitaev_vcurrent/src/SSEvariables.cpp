#include "../include/SSElattice.hpp"
#include "../include/SSEvariables.hpp"
#include <fstream>
#include <iostream>
#include <iomanip>
//#include <filesystem>


void
SSEvariables::declare_variables()
{
	// Read input variables from file.
	std::string INPUT_FILE = "input_param.dat";
	std::ifstream vars(INPUT_FILE);
	vars >> lx;
	vars >> lz;
	vars >> Jzz; 			// xx interaction, Jxx
	//vars >> Jzz;      // zz interaction, Jzz
	vars >> Beta;     // inverse temperature
	vars >> isteps;   // equilibration steps
	vars >> iter;     // measurements steps
  vars >> time_series;
	
	
  Jxx = 1 - Jzz; // Since Jxx = lambda and Jzz = 1 - Lambda.

	// Initialize global system variables;
	Ns = lx * lz;			// No. of Fundamental spins.
	Nb = Ns;					// Total number of x-bonds/z-bonds. Overall there are 2*Ns bonds.
	if (lx*lz==4){
		Nb = Ns/2;
	}




	// Individual probs
  prob_in = 0.25 * Jxx * Nb * Beta;   // for x-bonds
  prob_in += 0.5 * Jzz * Nb * Beta;   // for z-bonds
 	prob_rm = 1.0/prob_in;	

//  prob_in1 = 0.25 * Jxx * Nb * Beta;   // for x-bonds
//  prob_in2 = 0.5 * Jzz * Nb * Beta;   // for z-bonds


//  prob_rm1 = 1/prob_in1;//0.25 * Jxx * Nb * Beta;   // for x-bonds
//  prob_rm2 = 1/prob_in2;//0.5 * Jzz * Nb * Beta;   // for z-bonds

	// Combined probs
	cum_prob[0] = 0.25 * Jxx * Nb * Beta / prob_in;
	cum_prob[1] = 0.50 * Jzz * Nb * Beta / prob_in;



	//std::cout << prob_in[1] << "  " << prob_rm[1] << std::endl; 


  Lc = 30;
  n1 = 0;
  nl = Beta*lx;
}


void SSEvariables::lattice_sites()
{
	if (lx*lz == 4){
		// Square plaquette. 
		// Heisenberg bonds.

		JHsgny = new int [2*Nb];
		JHsgnx = new int [2*Nb];
		JHsites = new int *[2*Nb];
		for (int i = 0; i < 2*Nb; ++i) JHsites[i] = new int[2];


    // Jxx bonds
		JHsites[0][0] = 0;		
		JHsites[0][1] = 1;
		JHsgnx[0] = 1;
		JHsgny[0] = 0;



		JHsites[1][0] = 2;		
		JHsites[1][1] = 3;
		JHsgnx[1] = 1;
		JHsgny[1] = 0;


    // Jzz bonds
		JHsites[2][0] = 0;		
		JHsites[2][1] = 2;
		JHsgnx[2] = 0;
		JHsgny[2] = 1;
		
		JHsites[3][0] = 1;		
		JHsites[3][1] = 3;
		JHsgnx[3] = 0;
		JHsgny[3] = 1;
	}		
	else {
		// Square lattice 2D Kitaev. 
		// Kitaev bonds.
		JHsgny  = new int [2*Nb];  // JHsgny = 1 and JHsgnx = 0 for  z-bond, and oppoite for x-bond.
		JHsgnx  = new int [2*Nb];
		JHsites = new int *[2*Nb];
		for (int i = 0; i < 2*Nb; ++i) JHsites[i] = new int[2];

		
		for (int y1 = 0; y1 < lz; ++y1)
		{
			for (int x1 = 0; x1 < lx; ++x1)
			{
				// ***************************************************************************************
				// 												Kitaev interaction bonds
				// ***************************************************************************************	
				
        // Jxx bonds	
				int s1 = x1 + y1 * lx;
				int x2 = (x1 + 1) % lx;
				int s2 = x2 + y1 * lx;
			

				JHsites[s1][0] = s1;
				JHsites[s1][1] = s2;
				JHsgny[s1]     = 0;
        JHsgnx[s1]     = 1;

				// Jzz bonds
				x2 = x1;
				int y2 = (y1+1) % lz;
				s2 = x2+y2*lx;
				
				JHsites[Nb+s1][0] = s1;
				JHsites[Nb+s1][1] = s2;
				JHsgny[Nb+s1]     = 1;
        JHsgnx[Nb+s1]     = 0;


			}
		}
	//std::cout << "v" << std::endl;
	}
/*
	for (int i=0; i < 2*Nb; ++i){
		std::cout<<	"bond no >>"<< i <<" site_1 = "<< JHsites[i][0]<<" site_2 = "<< JHsites[i][1]<<std::endl;
	}
*/
	
}



