#include "../include/SSElattice.hpp"
#include "../include/SSEvariables.hpp"
#include "../include/SSEobservables.hpp"
#include "../include/SSEupdates.hpp"			//Headers
#include "../include/writeresults.hpp"
#include <chrono>
#include <iostream>
#include <sstream>
#include <fstream>
#include <iomanip>

static ran rann;
#define PRINT_VAR(name) std::cout << #name << ": " << vars.name << std::endl


int main() {
    SSEvariables vars;    // Creating all necessary instances
    SSEobservables obs;
    SSEupdates update;
    writeresults write;

    vars.declare_variables();
    vars.lattice_sites();

    update.initvrtx_dirloop();
    update.initialize(vars);
    update.weights();

    SSElattice* lattice = new SSElattice[vars.Ns];
    for (int xc = 0; xc < vars.Ns; ++xc)
        lattice[xc].set_S((rann() <= 0.5) ? -1 : 1);  // Start with a random configuration

    PRINT_VAR(lx), PRINT_VAR(lz), PRINT_VAR(Jxx), PRINT_VAR(Jzz), PRINT_VAR(Beta),
        PRINT_VAR(isteps), PRINT_VAR(iter), PRINT_VAR(time_series);

    auto t1 = std::chrono::high_resolution_clock::now();

    // ********************** Equilibration steps *************************
    for (int i = 0; i < vars.isteps; ++i) {
        update.mcstep(lattice, vars);  // Equilibration to check how much time it takes to complete.
        update.checkl(vars);
    }

    auto t2 = std::chrono::high_resolution_clock::now();
    auto elapsed = std::chrono::duration_cast<std::chrono::nanoseconds>(t2 - t1);
    double time = (elapsed.count() * 1e-9) / 60.;
    std::cout << "Total Equilibration time ~ " << time << " minutes" << std::endl;

    obs.Initiate_observables(vars);  // Initiate Observables.

    // ********************** Measurement steps ***************************
    std::ofstream outputFile("SSE_data_time_series.txt", std::ios::app);
    if (!outputFile.is_open()) {
        std::cerr << "Error opening the file." << std::endl;
        return 1;
    }

    if (outputFile.tellp() == 0)
        for (const auto& colHeader : {"Energy", "Mag^2"})
            outputFile << std::setw(15) << colHeader;

    for (int i = 0; i < vars.iter; ++i) {
        update.mcstep(lattice, vars);
        obs.measurements(vars, lattice);
        if (vars.time_series)
            write.save_time_series_data(outputFile, obs.enrg_time, obs.magZ_square_time);
    }

    outputFile.close();

    // obs.normalize_measurements(vars, lattice); // Observables normalization.

    write.save_bin_data(obs.enrg_bin, obs.magZ_square_bin);
    write.dumpArrayToFile(vars, obs.szsz);

    t1 = std::chrono::high_resolution_clock::now();
    elapsed = std::chrono::duration_cast<std::chrono::nanoseconds>(t1 - t2);
    time = (elapsed.count() * 1e-9) / 60.;
    std::cout << "Total Measurements time ~ " << time << " minutes." << std::endl;

    delete[] lattice;
    return 0;
}

