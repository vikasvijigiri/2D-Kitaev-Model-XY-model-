#include "../include/SSEvariables.hpp"
#include "../include/writeresults.hpp"

#include <sstream>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstring>


using namespace std;


template <typename... Args>
void writeresults::save_time_series_data(std::ofstream& outputFile, const Args&... args) {
    ((outputFile << std::setw(15) << std::scientific << args),... );
    outputFile << '\n';
}



//***************************************************************************************
template <typename... Args>
void writeresults::save_bin_data(const Args&... args) {


    // Open the file in append mode
    std::ofstream outputFile("SSE_data_avg.txt", std::ios::app);

    // Check if the file is open
    if (!outputFile.is_open()) {
        std::cerr << "Error opening the file." << std::endl;
        //return 0; // return an error code
    }

    // Check if the file is empty (to determine whether to write the header)
    outputFile.seekp(0, std::ios::end);
    bool fileIsEmpty = outputFile.tellp() == 0;

    // Write the header if the file is empty
    if (fileIsEmpty) {
      const char* headers[] = {"Energy", "Mag^2"};
      // Write the header to the file
      for (const auto& colHeader : headers) {
          outputFile << std::setw(15) << colHeader;
      }
      outputFile << '\n';
    }
    
    ((outputFile << std::setw(15) << std::scientific << args),... );

    outputFile << '\n';

    // Close the file
    outputFile.close();
}


void 
writeresults::dumpArrayToFile(SSEvariables sv, const double* arr) {
    // Open the file
    std::ofstream outFile("SSE_szsz_avg.txt", std::ios::app);

    // Check if the file is successfully opened
    if (!outFile) {
        std::cerr << "Error opening file: " << "SSE_szsz_avg.txt" << std::endl;
        return;
    }

    // Check if the file is empty (to determine whether to write the header)
    outFile.seekp(0, std::ios::end);
    bool fileIsEmpty = outFile.tellp() == 0;

    // Write the header if the file is empty
    if (fileIsEmpty) {
      //const char* headers[] = {"Sz"};
      // Write the header to the file
//      for (int i = 0; i < sv.Ns; ++i) {
//          std::ostringstream oss;
//          oss << "Sz_0Sz_" << i;
//          const char* header = oss.str().c_str();
//          outFile << std::setw(15) << header;
//      }
      for (int i = 0; i < sv.Ns; ++i) {
          //std::ostringstream oss;
          //oss << "Sz_0Sz_" << i;
          //const char* header = oss.str().c_str();
          outFile << std::setw(15) << std::scientific << "Sz_0Sz_" << i;
      }
      outFile << '\n';
    }



   // Write the array as a new column to the file
    for (int i = 0; i < sv.Ns; ++i) {
        // Move to a new row (if not the first row)
//        if (i > 0) {
//            outFile << std::endl;
//        }

        // Write the element to the current column
        outFile << std::setw(15) << std::scientific << arr[i];
    }
    outFile << '\n';
    // Move to the next column
//    outFile << '\t';

    // Close the file
    outFile.close();


}











template void writeresults::save_time_series_data(std::ofstream& , const double& , const double& );
template void writeresults::save_bin_data(const double& , const double& );
