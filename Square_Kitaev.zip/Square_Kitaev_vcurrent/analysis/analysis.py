import os
import shutil



class update_data:
    def __init__(self, mdir):
        # System parameters
        self.mdir = mdir
        print("Hello, you are extracting *.dat files from ", mdir)


    def extract_dat_files(self, root_folder, output_folder):
        # Create the output folder if it doesn't exist
        # Create the output folder if it doesn't exist
        try:
            os.mkdir(output_folder)
            print(f"Directory '{output_folder}' created successfully.")
        except FileExistsError:
            print(f"Directory '{output_folder}' already exists.")
        os.chmod(output_folder, 0o777)

        # Iterate through all subdirectories and extract *.dat files
        for foldername, subfolders, filenames in os.walk(root_folder):
            for filename in filenames:
                if filename.endswith('.dat'):
                    file_path = os.path.join(foldername, filename)
                    # Copy the *.dat file to the output folder
                    shutil.copy(file_path, output_folder)
                    print(f"Extracted: {file_path} to {output_folder}/{filename}")

# Replace 'your_root_folder' and 'your_output_folder' with the actual paths
#root_folder = 'your_root_folder'
#output_folder = 'your_output_folder'

def run_update(root_folder, output_folder):  
    upd = update_data(root_folder)      
    upd.extract_dat_files(root_folder, output_folder)

