try:
    import os
except ImportError:
    print("Import error: module 'os' is not installed or broken.")

try:
    import numpy as np
except ImportError:
    print("Import error: module 'numpy' is not installed.")
    print("Would you like to install this package?")
    if input("prompt") == 'yes' or input("prompt") == 'y':
        os.system('pip install numpy')


try:
    import matplotlib as mpl
except ImportError:
    print("Import error: module 'matplotlib' is not installed.")
    print("Would you like to install this package?")
    if input("prompt") == 'yes' or input("prompt") == 'y':
        os.system('python -m pip install -U matplotlib')

try:
    import matplotlib.pyplot as plt
except ImportError:
    print("Import error: module 'matplotlib' is not installed.")
    print("Would you like to install this package?")
    if input("prompt") == 'yes' or input("prompt") == 'y':
        os.system('python -m pip install -U matplotlib')


try:
    import scipy as sp
    from scipy.optimize import curve_fit
except ImportError:
    print("Import error: module 'scipy' is not installed.")
    print("Would you like to install this package?")
    if input("prompt") == 'yes' or input("prompt") == 'y':
        os.system('pip install scipy')

try:
    from scipy import interpolate
except ImportError:
    print("Import error: module 'scipy' is not installed.")
    print("Would you like to install this package?")
    if input("prompt") == 'yes' or input("prompt") == 'y':
        os.system('pip install scipy')

try:
    import linecache
except ImportError:
    print("Import error: module 'linecache' is not installed.")
    print("Would you like to install this package?")
    if input("prompt") == 'yes' or input("prompt") == 'y':
        os.system('pip install scipy')

try:
    import re
except ImportError:
    print("Import error: module 're' is not installed or broken.")
    print("Your python installation directory is not in ~/bin.")


try:
    import sys
except ImportError:
    print("Import error: module 'sys' is not installed or broken.")
    print("Your python installation directory is not in ~/bin.")



try:
    from multiprocessing import Pool
except ImportError:
    print("Error in 'multiprocessing', It might have not been installed/corrupt.")

try:
  import pandas as pd
except ImportError:
    print("Package 'pandas' is not installed. Use 'pip install pandas' to install.")

from scipy.interpolate import interp1d


############################################################################################################
# 									                  Updating data
############################################################################################################
class update_data:
    def __init__(self):
        # System parameters
        print("Hellos.")
        print("Welcome to the data updater. About to update the master data... Please wait!")
        self.rel_path = os.getcwd() + "/../../mDataFiles/"
        self.opath = os.getcwd() + "/../../oDataFiles/"
        self.opdf = os.getcwd() + "/../../plots/"
        #self.file_dir = file_dir
    
    def fnc(self, dir):
        d = [x[0] for x in os.walk(dir)]
        #filext = list(d[0].split("/"))[-4:-2] 
        #filextn = filext[0] +"_"+ filext[1] 
        dd = [x for x in d if (y := re.search(r"L+\d?\d", x)) is not None]
        lv = [self.string_to_StringNum(ddd)[0] for ddd in dd]
        lv = np.array(lv) 
        dd = np.array(dd)
        dd = dd[np.lexsort(([eval(i) for i in lv[:,2]], [eval(i) for i in lv[:,3]]))]  # Ascending order, put a '-' sign infront of arr[] for descending order.
        return dd#, filextn

    def extract_params_from_dirs(self, file_dir):
        ################################################
        d = self.fnc(file_dir)
        #print(d)
        ls, lf = self.string_to_StringNum(d[0])
        filext = lf[0] +"_"+ str(ls[0]) +"_"+  lf[1] +"_"+ str(ls[1]) 
        ################################################
        masterdataall_fname = self.rel_path+'masterdataNEW_'+filext.replace('.','p') + '.dat'
        os.system('rm ' + str(masterdataall_fname))
        file = open(masterdataall_fname, 'a')
        ################################################
        for i in range(len(lf)):
          sarr = np.array(["#  "+ lf[i] +" = "+ls[i]])
          np.savetxt(file, sarr, fmt="%s",  newline=" ")
          file.write("\n")
        #ffilename = str(d[3]) + '/output_seeded_data_input_details.txt'
        #print(ffilename)
        #sf_replace = ['enrg', 'mag^2' , 'mag^4' , 'stif' , 'O_N' , 'R_N' , 'O_V' , 'R_V' , 'O_B' , 'R_B', "binder"]
        sarr = np.array([lf[3], lf[2]] + sum([[sf_replace[i]+"_avg", sf_replace[i]+"_err"] for i in range(len(sf_replace))],[]))
        np.savetxt(file, sarr, fmt="%s",  newline=" ", delimiter=' ,')
        file.write("\n\n\n")
        ################################################
        l = [float(s) for s in re.findall(r'-?\d+\.?\d*', d[0])][3]   
        for i in range(len(d)):
            o = [float(s) for s in re.findall(r'-?\d+\.?\d*', d[i])]
            #print(l,o) 
            if l == o[3]: 
                filename = str(d[i]) + '/output_seeded_data_avg.txt'
                #print(filename)
                if os.path.isfile(filename):
                    #print(filename)
                    dt = self.avg_extimator(filename, o[3], o[2])
                    #print(dt)
                    np.savetxt(file, dt, fmt='%16.6e', newline=" ")  
                    file.write("\n")
            else: 
                filename = str(d[i]) + '/output_seeded_data_avg.txt'
                #print(filename)
                file.write("\n") 
                if os.path.isfile(filename):
                    #print(filename)
                    dt = self.avg_extimator(filename, o[3], o[2])
                    #print(dt)
                    np.savetxt(file, dt, fmt='%16.6e', newline=" ") 
                    file.write("\n")   
                l = o[3]        

        file.close()
        return masterdataall_fname


    def string_to_StringNum(self,ls):
        li = list(ls.split("/"))[-4:]  
        def parseint(string):
            m = re.search(r"-?\d+\.?\d*", string)
            return m.group() if m else None
        return [parseint(string) for string in li], [re.sub('-?\d+\.?\d*', '', line) for line in [re.sub('_', '', line) for line in li]]

    def get_file(self,file_dir):
        d = self.fnc(file_dir)
        ls, lf = self.string_to_StringNum(d[0])
        filext = lf[0] +"_"+ str(ls[0]) +"_"+  lf[1] +"_"+ str(ls[1]) 
        ################################################
        return self.rel_path+'masterdataNEW_'+filext.replace('.','p') + '.dat'


    def avg_extimator(self, filename, p1, p2):
#        def binder(m2,m4):
#            return 2.5*(1.0 - m4/(3.0*m2**2))   
        # Jackniffe average and error propagation
        df = np.genfromtxt(filename, unpack=True, dtype=np.float64, header=True)
        num_lines = sum(1 for line in open(filename))
        #print(filename)
        if num_lines > 1:
            l = len(df[:,0])
            y = [ea.jackknife(df[col][:]) for col in range(l)]
            # edited June 2023
            #B = ea.jackknife_on_function(binder, df[1][:], df[2][:] )  
            darr = [p1, p2] + list(sum(y,())) #+ list(B)
            return darr
        else:
            print("Warning: Not enough data points for fug, L =", p2, p1, "skipping!")
            return df[:]
    '''
    def sort_array(self,arr):
        arr = np.array(arr) 
        arr = arr[np.lexsort((arr[:, 1], arr[:, 0]))]  # Ascending order, put a '-' sign infront of arr[] for descending order.
        return arr
    def replacer(self,file,sarr):
        with open(file, 'r') as file:
            data = file.readlines()
        data[8] = sarr
        with open(file, 'w') as file:
            file.writelines(data)
    '''



def run_update(dir, header):  
    upd = update_data()      
    return upd.extract_params_from_dirs(dir)

def run_get_file(dir):  
    upd = update_data()      
    return upd.get_file(dir)


