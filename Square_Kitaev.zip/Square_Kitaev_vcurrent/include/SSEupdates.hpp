#ifndef SSEUPDATES_H
#define SSEUPDATES_H

#include <list>

class SSElattice;
class SSEvariables;
class SSEobservables;

class SSEupdates {
public:
    SSEupdates() {}

    int *str, *tbnd, *frst, *last;
    static const int nvx = 8;
    double amax, wgt[2][2], awgt[2][2], dwgt[2][2];
    int vxoper[nvx + 1], legvx[2][2][2][2], vxleg[4][nvx + 1], vxnew[4][4][nvx + 1];
    double vxprb[4][4][nvx + 1], vxp[4][4][nvx + 1];

    std::list<int> cstack;

    void weights(), initvrtx_dirloop(), mcstep(SSElattice*, SSEvariables&), mcstep_measurement(SSElattice*, SSEvariables&, SSEobservables&), checkl(SSEvariables&);
    void diag_update(SSElattice*, SSEvariables&), looper(SSElattice*, SSEvariables&), initialize(SSEvariables&);
};

#endif

