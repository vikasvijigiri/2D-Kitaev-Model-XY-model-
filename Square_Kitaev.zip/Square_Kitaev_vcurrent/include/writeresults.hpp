#ifndef _WRITERESULTS_HPP_DEFINED_
#define _WRITERESULTS_HPP_DEFINED_


#pragma once
class writeresults {
	public:
  template <typename... Args>
  void save_bin_data(const Args&... args);

  template <typename... Args>
  void save_time_series_data(std::ofstream& , const Args&... args);


  void dumpArrayToFile(SSEvariables , const double* );
};
#endif
