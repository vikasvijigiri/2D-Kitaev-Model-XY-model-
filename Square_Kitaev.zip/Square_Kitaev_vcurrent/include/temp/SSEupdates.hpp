#ifndef _SSEUPDATES_HPP_DEFINED_
#define _SSEUPDATES_HPP_DEFINED_

class SSEupdates {
	public: 
	SSEupdates(){}

    // ********************************************************************
    // 		Update related structures 
    // ********************************************************************

	  long *str;	//, *pstr;
    int *frst, *last; 
   	static const int nvx=6;
   	const double pi = 2. * acos(0.);
	  
	  
   	double amax;
   	double wgt[2][2];
   	double awgt[2][2];
   	double dwgt[2][2];
	  

		/*
   	int vxoper[nvx+1];
   	int legvx[2][2][2][2];
   	int vxleg[4][nvx+1];
   	int vxnew[4][4][nvx+1];
   	double vxprb[4][4][nvx+1];
   	double vxp[4][4][nvx+1];

	  
   	int nl;
		*/	  



	  void weights();
	  //void initvrtx_dirloop();

	  void mcstep(int, SSElattice* );
	  //void mcstep_measurement(SSElattice* );
	  void checkl(SSEvariables );
	  
	  
	  void diag_update(SSElattice*, SSEvariables);				
	  void looper(SSElattice* );
	  //void diag_update_measurement(SSElattice * ); 
	  //void looper_measurement(SSElattice *  );
    void initialize(SSEvariables );
    


};
#endif

