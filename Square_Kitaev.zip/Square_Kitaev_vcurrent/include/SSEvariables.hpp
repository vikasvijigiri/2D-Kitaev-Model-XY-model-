#ifndef _SSEVARIABLES_HPP_DEFINED_
#define _SSEVARIABLES_HPP_DEFINED_
#include <random>
#include <chrono>
using namespace std::chrono;

#pragma once


class SSEvariables {
	public:
    bool time_series;
    int lx, lz, Ns, Nb, nbins, isteps, iter, nl; 
    double Jzz, Jxx, Beta;
    double prob_in, prob_rm, cum_prob[2];
//    double prob_in1, prob_in2, prob_rm1, prob_rm2;
    long n1, Lc;
    int **JHsites, *JHsgny, *JHsgnx;

  	void lattice_sites( );
  	void declare_variables();
  	//void set_temperatures();

};

class ran {
  private:
    std::mt19937 mt;
    std::uniform_real_distribution < double > dist;

  public:
    ran(double lower = 0.0, double upper = 1.0): mt(std::chrono::high_resolution_clock::now().time_since_epoch().count()), dist(lower, upper) {}
    double operator()() {
    return dist(mt);
    }
};
#endif
