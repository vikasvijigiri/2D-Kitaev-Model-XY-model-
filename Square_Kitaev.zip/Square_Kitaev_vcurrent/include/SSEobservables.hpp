#ifndef _SSEOBSERVABLES_HPP_DEFINED_
#define _SSEOBSERVABLES_HPP_DEFINED_

#pragma once
class SSEobservables {
  	public:

			  // Observables
      	double enrg_bin, magZ_square_bin;
        double enrg_time, magZ_square_time;
        double *szsz;

        // Observable functions
        void measurements(SSEvariables , SSElattice* );	
        double magnetization(SSEvariables , SSElattice* );
        void ZZCorrelation(SSEvariables , SSElattice* );

		    // Initiate Observables.
      	void Initiate_observables(SSEvariables );
};
#endif


