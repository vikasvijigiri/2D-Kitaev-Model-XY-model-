Licenced by Vikas Vijigiri. Easily portable.

Free to use the code and distribute. Citation is not just a moral oblique but a respect.


Ways to install:
#-----------------

1) Just run test_prepare.py inside the build directory. 
   * This will create subdirectories with each parameter values inscribed in the directory. E.g. J_H_0.0 would imply The J_H cou;ling with value 0.0.
   
   
The    
   
    

